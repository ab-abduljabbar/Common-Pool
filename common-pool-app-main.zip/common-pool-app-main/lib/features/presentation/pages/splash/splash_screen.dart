import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';

class SplashScreen extends StatefulWidget {
  final Widget? child;
  const SplashScreen({Key? key, this.child}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {
    Future.delayed(Duration(seconds: 3), () {
      Navigator.pushAndRemoveUntil(context,
          MaterialPageRoute(builder: (_) => widget.child!), (route) => false);
    });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: primaryColor,
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Center(child: Text("Welcome To",style: TextStyle(fontSize: 30),)),
            MainTextWidget(text: "Common Pool", size: 45, dotColor: Colors.redAccent, mainAxisAlignment: MainAxisAlignment.center,)
          ],
        ),
      ),
    );
  }
}
