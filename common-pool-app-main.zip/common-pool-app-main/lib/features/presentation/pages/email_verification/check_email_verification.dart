import 'dart:async';

import 'package:common_pool_app/injection_container.dart' as di;
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../../../consts.dart';
import '../../../../theme/colors.dart';
import '../../../domain/entities/user_entity.dart';
import '../../../domain/use_cases/user_usecases/is_check_email_verification_usecase.dart';
import '../../cubit/auth/auth_cubit.dart';
import '../../cubit/feedback/feedback_cubit.dart';
import '../../cubit/single_user/single_user_cubit.dart';
import '../../cubit/user/user_cubit.dart';
import '../../widgets/common.dart';
import '../../widgets/container_button_icon_widget.dart';
import '../home/home_root.dart';

class CheckEmailVerification extends StatefulWidget {
  final String uid;

  const CheckEmailVerification({Key? key, required this.uid}) : super(key: key);

  @override
  State<CheckEmailVerification> createState() => _CheckEmailVerificationState();
}

class _CheckEmailVerificationState extends State<CheckEmailVerification> {
  Timer? _timer;

  final user = di.sl<FirebaseAuth>();

  @override
  void initState() {
    BlocProvider.of<SingleUserCubit>(context).getSingleUser(uid: widget.uid);


    _timer = Timer.periodic(Duration(seconds: 5), (timer) => _checkEmailVerification());
    super.initState();
  }

  ///dispose timer
  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  ///email check if email verified then navigate user to home screen
  Future<void> _checkEmailVerification() async {
    await user.currentUser!.reload();

    di.sl<IsCheckEmailVerificationUseCase>().call().then((value) {
      print("check Email ${user.currentUser!.emailVerified}");

      if (value == true) {
        _timer?.cancel();
        BlocProvider.of<UserCubit>(context).getUpdateUser(UserEntity(
          uid: widget.uid,
          isVerified: true,
        ));
      }
    });
    // if (user.currentUser!.emailVerified==true) {
    //
    //   //cancel running timer when email verified
    //   //check email verification and navigate user to home screen and
    //   //update isVerified flag to true
    //
    // }
  }

  ///send email verification
  Future<void> _sendEmailVerification() async {
    try {
      await user.currentUser!.sendEmailVerification().then((value) {
        print("email has been sent to your email");
        toast("Email verification has been sent to your email");
      });
    } catch (_) {
      toast("Please check your email, Email verification has been sent to your email");
      print("something went wrong");
    }
  }

  @override
  Widget build(BuildContext context) {
    return BlocBuilder<SingleUserCubit, SingleUserState>(
      builder: (context, singleUserState) {
        if (singleUserState is SingleUserLoaded) {

                final singleUser = singleUserState.user;
                if (singleUser.isVerified == false) {
                  /// FIXME
                  _sendEmailVerification();
                  return _verifiedEmailWidget();
                } else if (singleUser.isVerified == true) {
                  if (_timer != null) _timer?.cancel();
                  return HomeRoot(currentUser: singleUser);
                } else {
                  return Center(
                    child: CircularProgressIndicator(),
                  );
                }
              }
              return Center(
                child: CircularProgressIndicator(),
              );
            },

          );

        }



  Widget _verifiedEmailWidget() {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text("A verification email has been sent to your email"),
            SizedBox(
              height: 20,
            ),
            ContainerButtonIconWidget(
              title: "Resend Email verification",
              color: primaryColor,
              isEnableBoxShadow: true,
              width: 250,
              onClickListener: () {
                _sendEmailVerification();
              },
            ),
            SizedBox(
              height: 20,
            ),
            InkWell(
                onTap: () {
                  BlocProvider.of<AuthCubit>(context).loggedOut().then((value) {
                    Navigator.pushNamedAndRemoveUntil(context, PageConst.loginPage, (route) => false);
                  });
                },
                child: Text("Login back"))
          ],
        ),
      ),
    );
  }
}
