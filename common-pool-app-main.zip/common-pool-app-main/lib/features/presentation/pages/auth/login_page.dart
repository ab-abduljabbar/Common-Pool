import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/presentation/pages/home/home_root.dart';
import 'package:common_pool_app/features/presentation/widgets/drop_down_button_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/form_container_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../cubit/auth/auth_cubit.dart';
import '../../cubit/auth/credential/credential_cubit.dart';
import '../email_verification/check_email_verification.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  TextEditingController? _emailController = TextEditingController();
  TextEditingController? _passwordController = TextEditingController();

  @override
  void dispose() {
    _emailController!.dispose();
    _passwordController!.dispose();
    super.dispose();
  }

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static const emailRegex = r"""^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+""";

  Object _groupValue = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<CredentialCubit, CredentialState>(
        listener: (context, credentialState) {
          if (credentialState is CredentialSuccess) {
            BlocProvider.of<AuthCubit>(context).loggedIn();
          }
          if (credentialState is CredentialFailure) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Invalid Credentials")));
          }
        },
        builder: (context, credentialState) {
          if (credentialState is CredentialLoading) {
            return Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (credentialState is CredentialSuccess) {
            return BlocBuilder<AuthCubit, AuthState>(builder: (context, authState) {
              if (authState is Authenticated) {
                return CheckEmailVerification(uid: authState.uid);
              } else {
                print("Unauthenticated");
                return _bodyWidget();
              }
            });
          }
          return _bodyWidget();
        },
      ),
    );
  }

  _bodyWidget() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 40),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              MainTextWidget(
                text: "Login",
              ),
              sizeVer(40),
              FormContainerWidget(
                controller: _emailController,
                height: 60,
                hintText: "Email",
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return "field cannot be empty";
                  } else if (RegExp(emailRegex).hasMatch(value)) {
                  } else {
                    return "email not correctly formatted";
                  }
                },
              ),
              sizeVer(15),
              FormContainerWidget(
                controller: _passwordController,
                height: 60,
                hintText: "Password",
                isPasswordField: true,
                validator: (value) {
                  if (value == "" || value == null) {
                    return "field cannot be empty";
                  } else if (value.length < 6) {
                    return "must be at least 6 characters";
                  } else {
                    return null;
                  }
                },
              ),
              sizeVer(10),
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, PageConst.forgetPasswordPage);
                  },
                  child: Text(
                    "Forget Password?",
                    style: TextStyle(color: primaryColor, decoration: TextDecoration.underline),
                  ),
                ),
              ),
              sizeVer(30),
              ButtonContainerWidget(
                text: "Login",
                width: double.infinity,
                height: 45,
                fontWeight: FontWeight.bold,
                boxShadow: [
                  BoxShadow(color: Colors.black54, blurRadius: 5, spreadRadius: 0.5, offset: Offset(1, 2.5)),
                ],
                onTap: () {
                  _submitLogin();
                },
              ),
              sizeVer(50),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Don't have an account?",
                    style: TextStyle(fontSize: 16),
                  ),
                  sizeHor(5),
                  InkWell(
                      onTap: () {
                        Navigator.pushNamedAndRemoveUntil(context, PageConst.signUpPage, (route) => false);
                      },
                      child: Text(
                        "Register?",
                        style: TextStyle(color: primaryColor, fontSize: 16, decoration: TextDecoration.underline),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _submitLogin() {
    if (_formKey.currentState!.validate()) {
      // if (_emailController!.text.isEmpty) {
      //   toast("Enter your email");
      //   return;
      // } else if (RegExp(emailRegex).hasMatch(_emailController!.value.text)) {
      // } else {
      //   toast("Enter not correctly formatted");
      // }
      // if (_passwordController!.text.isEmpty) {
      //   toast("Enter your password");
      //   return;
      // }
      BlocProvider.of<CredentialCubit>(context).signInSubmit(
        email: _emailController!.text,
        password: _passwordController!.text,
      );
    } else {
      return null;
    }

  }

}
