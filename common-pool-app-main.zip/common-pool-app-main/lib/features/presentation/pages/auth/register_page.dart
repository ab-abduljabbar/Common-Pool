import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/presentation/pages/email_verification/check_email_verification.dart';
import 'package:common_pool_app/features/presentation/pages/home/home_root.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/form_container_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:geocoder/model.dart';
import 'package:location_permissions/location_permissions.dart';
import '../../../domain/entities/user_entity.dart';
import '../../cubit/auth/auth_cubit.dart';
import '../../cubit/auth/credential/credential_cubit.dart';
import '../../widgets/form_container_and_password_widget.dart';
import '../../widgets/map_location_picker_widget.dart';
import 'package:location_permissions/location_permissions.dart' as pr;

class RegisterPage extends StatefulWidget {
  const RegisterPage({Key? key}) : super(key: key);

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  TextEditingController? _usernameController = TextEditingController();
  TextEditingController? _emailController = TextEditingController();
  TextEditingController? _passwordController = TextEditingController();
  TextEditingController? _phoneController = TextEditingController();
  TextEditingController? _carController = TextEditingController();
  TextEditingController? _carModelController = TextEditingController();
  TextEditingController? _numberOfSeatsController = TextEditingController();
  TextEditingController? _addressController = TextEditingController();
  Coordinates? _pickUpLocationLatLong;


  @override
  void dispose() {
    _emailController!.dispose();
    _passwordController!.dispose();
    _usernameController!.dispose();
    _phoneController!.dispose();
    _carController!.dispose();
    _carModelController!.dispose();
    _numberOfSeatsController!.dispose();
    _addressController!.dispose();
    super.dispose();
  }

  GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  static const emailRegex = r"""^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+""";

  Object _groupValue = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocConsumer<CredentialCubit, CredentialState>(
        listener: (context, credentialState) {
          if (credentialState is CredentialSuccess) {
            BlocProvider.of<AuthCubit>(context).loggedIn();
          }
          if (credentialState is CredentialFailure) {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Invalid Credentials")));
          }
        },
        builder: (context, credentialState) {
          if (credentialState is CredentialLoading) {
            return Scaffold(
              body: Center(child: CircularProgressIndicator()),
            );
          }
          if (credentialState is CredentialSuccess) {

            return BlocBuilder<AuthCubit, AuthState>(builder: (context, authState) {
              if (authState is Authenticated) {
                return CheckEmailVerification(uid: authState.uid);
              } else {
                print("Unauthenticated");
                return _bodyWidget();
              }
            });
          }
          return _bodyWidget();
        },
      ),
    );
  }

  _bodyWidget() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 15, vertical: 40),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              MainTextWidget(
                text: "Register",
              ),
              sizeVer(40),
              FormContainerWidget(
                controller: _usernameController,
                height: 60,
                hintText: "Username",
                validator: (value) {
                  if (value == "" || value == null) {
                    return "field cannot be empty";
                  } else if (value.length > 10) {
                    return "must be at least 10 characters";
                  } else {
                    return null;
                  }
                },
              ),
              sizeVer(15),
              FormContainerWidget(
                controller: _emailController,
                height: 60,
                hintText: "Email",
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "field cannot be empty";
                    } else if (RegExp(emailRegex).hasMatch(value)) {
                    } else {
                      return "email not correctly formatted";
                    }
                  }
              ),
              sizeVer(15),
              FormContainerWidget(
                controller: _phoneController,
                height: 60,
                hintText: "Phone Number",
                validator: (value) {
                  if (value == "" || value == null) {
                    return "field cannot be empty";
                  } else if (value.length < 11) {
                    return "must be at least 11 characters";
                  } else {
                    return null;
                  }
                },
              ),
              sizeVer(15),
              FormContainerAndPasswordWidget(
                controller: _passwordController,
                height: 60,
                isPasswordField: true,
                hintText: "Password",
                validator: (value) {
                  if (value == "" || value == null) {
                    return "field cannot be empty";
                  } else if (value.length < 6) {
                    return "must be at least 6 characters";
                  } else {
                    return null;
                  }
                },
              ),
              sizeVer(10),
              _groupValue == 1 ? Container() :InkWell(
                onTap: ()async{
                  final permission = await LocationPermissions().requestPermissions();
                  if (permission == pr.PermissionStatus.granted) {
                    Navigator.push(context, MaterialPageRoute(builder: (_) => MapLocationPickerWidget(
                      onLocationListener:
                          (Coordinates coordinates,
                          String address,
                          String adminArea) {
                        setState(() {
                          _addressController!.value =
                              TextEditingValue(
                                  text: "$address");
                          _pickUpLocationLatLong=coordinates;
                        });
                      },
                    )));
                  } else {}
                },
                child: Container(
                  height: 50,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(8),
                          bottomLeft: Radius.circular(8),
                          topRight: Radius.circular(8),
                          bottomRight: Radius.circular(8)),
                      border:
                      Border.all(width: 1, color: Colors.grey)),
                  child: Row(
                    children: [
                      Expanded(
                        child: AbsorbPointer(
                          child: TextFormField(
                            controller: _addressController,
                            keyboardType: TextInputType.text,
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                prefixIcon: Icon(
                                    Icons.add_location_alt_outlined),
                                hintText: "Address",
                                contentPadding: EdgeInsets.only(
                                    top: 15, left: 5)),
                          ),
                        ),
                      ),
                      SizedBox(
                        width: 10,
                      ),
                      Icon(Icons.add_location_outlined),
                      SizedBox(
                        width: 10,
                      ),
                    ],
                  ),
                ),
              ),
              _groupValue != 1 ? Container() : Column(
                children: [
                  FormContainerWidget(
                    controller: _carController,
                    height: 60,
                    hintText: "Car",
                    validator: (value) {
                      if (value == "" || value == null) {
                        return "field cannot be empty";
                      } else if (value.length > 20) {
                        return "must be at least 20 characters";
                      } else {
                        return null;
                      }
                    },
                  ),
                  sizeVer(10),
                  FormContainerWidget(
                    controller: _carModelController,
                    height: 60,
                    hintText: "Car Model",
                    validator: (value) {
                      if (value == "" || value == null) {
                        return "field cannot be empty";
                      } else if (value.length < 20) {
                        return "must be at least 20 characters";
                      } else {
                        return null;
                      }
                    },
                  ),
                  sizeVer(10),
                  FormContainerWidget(
                    controller: _numberOfSeatsController,
                    height: 60,
                    hintText: "Number of seats",
                    validator: (value) {
                      if (value == "" || value == null) {
                        return "field cannot be empty";
                      } else if (value.length > 1) {
                        return "must be at least 1 character";
                      } else {
                        return null;
                      }
                    },
                  ),
                  sizeVer(10),
                  InkWell(
                    onTap: ()async{
                      final permission = await LocationPermissions().requestPermissions();
                      if (permission == pr.PermissionStatus.granted) {
                        Navigator.push(context, MaterialPageRoute(builder: (_) => MapLocationPickerWidget(
                          onLocationListener:
                              (Coordinates coordinates,
                              String address,
                              String adminArea) {
                            setState(() {
                              _addressController!.value =
                                  TextEditingValue(
                                      text: "$address");
                              _pickUpLocationLatLong=coordinates;
                            });
                          },
                        )));
                      } else {}
                    },
                    child: Container(
                      height: 50,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(8),
                              bottomLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                              bottomRight: Radius.circular(8)),
                          border:
                          Border.all(width: 1, color: Colors.grey)),
                      child: Row(
                        children: [
                          Expanded(
                            child: AbsorbPointer(
                              child: TextFormField(
                                controller: _addressController,
                                keyboardType: TextInputType.text,
                                decoration: InputDecoration(
                                    border: InputBorder.none,
                                    prefixIcon: Icon(
                                        Icons.add_location_alt_outlined),
                                    hintText: "Address",
                                    contentPadding: EdgeInsets.only(
                                        top: 15, left: 5)),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Icon(Icons.add_location_outlined),
                          SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
              sizeVer(10),
              Row(
                children: [
                  Row(
                    children: [
                      Radio(
                        value: 0,
                        groupValue: _groupValue,
                        onChanged: (value) {
                          setState(() {
                            _groupValue = value!;
                          });
                        },
                      ),
                      sizeHor(10),
                      Text("Passenger"),
                    ],
                  ),
                  sizeHor(15),
                  Row(
                    children: [
                      Radio(
                        value: 1,
                        groupValue: _groupValue,
                        onChanged: (value) {
                          setState(() {
                            _groupValue = value!;
                          });
                        },
                      ),
                      sizeHor(10),
                      Text("Driver"),
                    ],
                  ),
                ],
              ),
              sizeVer(30),
              ButtonContainerWidget(
                text: "Register",
                width: double.infinity,
                height: 45,
                fontWeight: FontWeight.bold,
                boxShadow: [
                  BoxShadow(color: Colors.black54, blurRadius: 5, spreadRadius: 0.5, offset: Offset(1, 2.5)),
                ],
                onTap: () {
                  _submitSignUp();
                },
              ),
              sizeVer(65),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    "Already have an account?",
                    style: TextStyle(fontSize: 16),
                  ),
                  sizeHor(5),
                  InkWell(
                      onTap: () {
                        Navigator.pushNamedAndRemoveUntil(context, PageConst.loginPage, (route) => false);
                      },
                      child: Text(
                        "Login?",
                        style: TextStyle(color: primaryColor, fontSize: 16, decoration: TextDecoration.underline),
                      ))
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

  void _submitSignUp() {


    if (_groupValue == 0) {

      if (_formKey.currentState!.validate()) { // Passenger

        if (_addressController!.text.isEmpty){
          toast("Enter your address");
          return;
        }
        if (_pickUpLocationLatLong == null){
          toast("Please select location again");
          return;
        }
        BlocProvider.of<CredentialCubit>(context).signUpSubmit(
          user: UserEntity(
              email: _emailController!.text,
              username: _usernameController!.text,
              password: _passwordController!.text,
              totalRating: 0,
              photoUrl: "",
              phone: _phoneController!.text,
              numberOfSeats: "",
              carModel: "",
              car: "",
              locationPoint: GeoPoint(_pickUpLocationLatLong!.latitude, _pickUpLocationLatLong!.longitude),
              createAt: Timestamp.now(),
              address: _addressController!.text,
              about: "",
              accountType: AccountConst.passenger
          ),
        );
      } else {
        return null;
      }
    }

    if (_groupValue == 1) { // Driver
      if (_formKey.currentState!.validate()) {
        if (_addressController!.text.isEmpty){
          toast("Enter your address");
          return;
        }
        if (_pickUpLocationLatLong == null){
          toast("Please select location again");
          return;
        }
        BlocProvider.of<CredentialCubit>(context).signUpSubmit(
          user: UserEntity(
              email: _emailController!.text,
              username: _usernameController!.text,
              password: _passwordController!.text,
              totalRating: 0,
              photoUrl: "",
              phone: _phoneController!.text,
              numberOfSeats: _numberOfSeatsController!.text,
              carModel: _carModelController!.text,
              car: _carController!.text,
              locationPoint: GeoPoint(_pickUpLocationLatLong!.latitude, _pickUpLocationLatLong!.longitude),
              createAt: Timestamp.now(),
              address: _addressController!.text,
              about: "",
              accountType: AccountConst.driver
          ),
        );
      } else {
        return null;
      }

    }


  }
}


