import 'package:common_pool_app/features/presentation/cubit/auth/credential/credential_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/form_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

class ForgetPasswordPage extends StatefulWidget {
  const ForgetPasswordPage({Key? key}) : super(key: key);

  @override
  State<ForgetPasswordPage> createState() => _ForgetPasswordPageState();
}

class _ForgetPasswordPageState extends State<ForgetPasswordPage> {
  TextEditingController _emailController = TextEditingController();

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                  onTap: () {
                    Navigator.pop(context);
                  },
                  child: Icon(Icons.arrow_back_ios)),
              MainTextWidget(
                text: "Forget\nPassword",
                dotColor: primaryColor,
                size: 50,
                mainAxisAlignment: MainAxisAlignment.center,
              ),
              sizeVer(30),
              FormContainerWidget(
                controller: _emailController,
                hintText: "Email",
              ),
              sizeVer(20),
              Center(
                child: ButtonContainerWidget(
                  text: "Submit",
                  onTap: () {
                    if (_emailController.text.isEmpty) {
                      toast("Type your email in the field!");
                      return;
                    }
                    
                    BlocProvider.of<CredentialCubit>(context).forgotPassword(email: _emailController.text).then((value) {
                      setState(() {
                        _emailController.clear();
                      });
                      Navigator.pop(context);
                      toast("Please checkout your email");
                    });
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
