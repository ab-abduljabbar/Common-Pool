

import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/single_user/single_user_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../../../consts.dart';
import '../sub_pages/complete_rides_page.dart';
import '../sub_pages/my_rides_page.dart';
import '../sub_pages/waiting_rides_page.dart';
import '../widgets/driver_tabbar_widget.dart';
import '../widgets/passenger_tabbar_widget.dart';


class RidersPage extends StatefulWidget {
  final UserEntity userEntity;
  const RidersPage({Key? key, required this.userEntity}) : super(key: key);

  @override
  State<RidersPage> createState() => _RidersPageState();
}

class _RidersPageState extends State<RidersPage> {
  int _pageIndex = 0;

  @override
  void initState() {
    BlocProvider.of<BookRideCubit>(context)..getAllBookRides();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<SingleUserCubit, SingleUserState>(
          builder: (context, singleUserState) {

            if (singleUserState is SingleUserLoaded){

              final currentUser = singleUserState.user;

              return Padding(
                padding: const EdgeInsets.symmetric(
                    horizontal: 10.0, vertical: 10),
                child: Column(
                  children: [
                    Row(
                      children: [
                        // GoBackIconWidget(
                        //   onTap: () {
                        //     Navigator.pop(context);
                        //   },
                        // ),
                        Text(
                          "My Rides",
                          style: TextStyle(fontSize: 20),
                        ),
                      ],
                    ),
                    sizeVer(20),
                    currentUser.accountType == AccountConst.passenger?PassengerTabBar(
                      tabClickListener: (index) {
                        setState(() {
                          _pageIndex = index;
                        });
                      },
                      index: _pageIndex,
                    ):DriverTabBar(
                      tabClickListener: (index) {
                        setState(() {
                          _pageIndex = index;
                        });
                      },
                      index: _pageIndex,
                    ),
                    sizeVer(50),
                    _pageSwitch(currentUser),
                  ],
                ),
              );
            }

            return centerProgressBarIndicator();
          },
        ),
      ),
    );
  }

  Widget _pageSwitch(UserEntity currentUser) {
    switch (_pageIndex) {
      case 0:
        return Expanded(child: MyRidesPage(currentUser:currentUser,));
      case 1:
        return Expanded(child: CompleteRidesPage(currentUser: currentUser,));
      case 2:
        return Expanded(child: WaitingRidesPage(currentUser:currentUser,));
      default:
        return Container();
    }
  }


}
