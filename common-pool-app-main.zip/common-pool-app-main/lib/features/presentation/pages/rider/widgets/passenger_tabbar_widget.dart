import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';

import '../../../../../../../theme/colors.dart';


typedef TabClickListener = Function(int index);
class PassengerTabBar extends StatefulWidget {
  final TabClickListener tabClickListener;
  final index;

  const PassengerTabBar({Key? key, this.index = 1,required this.tabClickListener}) : super(key: key);

  @override
  _CustomPassengerTabBarState createState() => _CustomPassengerTabBarState();
}

class _CustomPassengerTabBarState extends State<PassengerTabBar> {
  int _indexHolder=0;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50,
      child: Row(
        children: [
          Expanded(
            child: TabBarCustomButton(
              width: 50,
              text: "My Rides",
              iconData:  Entypo.image,
              isIconData: false,
              textColor: widget.index == 0 ?primaryColor : Colors.black,
              borderColor: widget.index == 0 ? Colors.black : Colors.grey,
              onTap: (){
                setState(() {
                  _indexHolder=0;
                });
                widget.tabClickListener(_indexHolder);
              },
            ),
          ),
          Expanded(
            child: TabBarCustomButton(
              width: 50,
              text: "Complete Rides",
              isIconData: false,
              iconData:AntDesign.videocamera,
              textColor: widget.index == 1 ?primaryColor : Colors.black,
              borderColor: widget.index == 1 ? Colors.black : Colors.grey,              onTap: (){
              setState(() {
                _indexHolder=1;
              });
              widget.tabClickListener(_indexHolder);
            },
            ),
          ),
        ],
      ),
    );
  }
}

class TabBarCustomButton extends StatelessWidget {
  final String text;
  final double width;
  final double height;
  final Color borderColor;
  final double borderWidth;
  final Color textColor;
  final VoidCallback onTap;
  final bool? isIconData;
  final IconData? iconData;

  const TabBarCustomButton({
    Key? key,
    this.text="",
    this.isIconData=false,
    this.iconData,
    this.width = 50.0,
    this.height = 50.0,
    this.borderColor = Colors.white,
    this.borderWidth = 3.0,
    this.textColor = Colors.white,
    required this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        width: width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
            border: Border(
                bottom: BorderSide(color: borderColor, width: borderWidth))),
        child: isIconData==true?Icon(iconData):Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(
              fontSize: 14, fontWeight: FontWeight.w500, color: textColor),
        ),
      ),
    );
  }
}
