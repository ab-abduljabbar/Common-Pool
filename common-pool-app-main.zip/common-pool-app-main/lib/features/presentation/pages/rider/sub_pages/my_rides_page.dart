import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/alert/accept_price_alert.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:location_permissions/location_permissions.dart' as pr;
import 'package:location_permissions/location_permissions.dart';

import '../../../../domain/use_cases/user_usecases/get_single_user_usecase.dart';
import '../../../widgets/alert/cancel_ride_alert.dart';
import '../../../widgets/alert/complete_ride_alert.dart';
import '../../../widgets/form_container_widget.dart';
import '../../../widgets/track_map_location_widget.dart';
import 'package:common_pool_app/injection_container.dart' as di;

class MyRidesPage extends StatefulWidget {
  final UserEntity currentUser;

  const MyRidesPage({Key? key, required this.currentUser}) : super(key: key);

  @override
  State<MyRidesPage> createState() => _MyRidesPageState();
}

class _MyRidesPageState extends State<MyRidesPage> {
  TextEditingController _passengerCurrentAddressController = TextEditingController();
  TextEditingController _passengerDestinationController = TextEditingController();
  TextEditingController _passengerProposalPriceController = TextEditingController();

  TextEditingController _addressController = TextEditingController();
  Coordinates? _locationLatLng;

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    _passengerCurrentAddressController.dispose();
    _passengerDestinationController.dispose();
    _passengerProposalPriceController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<BookRideCubit, BookRideState>(
        builder: (context, bookRideState) {
          if (bookRideState is BookRideFailure) {
            return Center(
              child: Text("Some Error Occured"),
            );
          }
          if (bookRideState is BookRideLoaded) {
            final myBookRide = bookRideState.bookRideData
                .where(
                  (element) =>
                      element.creatorId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.inProgress ||
                      element.driverId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.inProgress ||
                      element.creatorId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.waiting,
                )
                .toList();

            // return _bodyWidget();
            return myBookRide.isEmpty
                ? Align(
                    alignment: Alignment.topCenter,
                    child: Text(
                      "No Rides Yet",
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                    ))
                : ListView.builder(
                    itemCount: myBookRide.length,
                    itemBuilder: (context, index) {
                      return _bodyWidget(bookRideEntity: myBookRide[index]);
                    },
                  );
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }

  _bodyWidget({required BookRideEntity bookRideEntity}) {
    if (bookRideEntity.bookingStatus == BookingStatusConst.inProgress) {
      return _ridesInProgress(
        bookRideEntity: bookRideEntity,
      );
    } else if (bookRideEntity.bookingStatus == BookingStatusConst.waiting) {
      return _myRides(bookRideEntity: bookRideEntity);
    } else {
      return Container();
    }
  }

  _myRides({required BookRideEntity bookRideEntity}) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              width: double.infinity,
              decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: Colors.black)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("Your Price"),
                  sizeVer(10),
                  AbsorbPointer(
                    child: FormContainerWidget(
                      // controller: _proposeController,
                      height: 60,
                      inputType: TextInputType.number,
                      hintText: "${bookRideEntity.passengerPrice}",
                    ),
                  ),
                  sizeVer(10),
                  bookRideEntity.driverPrice!.isNotEmpty || bookRideEntity.finalPrice!.isNotEmpty
                      ? Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Driver Updated his price to"),
                            sizeVer(10),
                            AbsorbPointer(
                              child: FormContainerWidget(
                                // controller: _proposeController,
                                height: 60,
                                inputType: TextInputType.number,
                                hintText: "${bookRideEntity.driverPrice}",
                              ),
                            ),
                          ],
                        )
                      : Container(),
                  sizeVer(10),
                  bookRideEntity.driverPrice!.isNotEmpty
                      ? FormContainerWidget(
                          controller: _passengerProposalPriceController,
                          height: 60,
                          inputType: TextInputType.number,
                          hintText: "propose your price again (optional)",
                        )
                      : Container(),
                  bookRideEntity.priceAgreementStatus == BudgetAgreementStatus.notAgreeYet && bookRideEntity.driverPrice!.isNotEmpty
                      ? Text(
                          "Propose your price again if you are not agree with Driver price.",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 16, color: primaryColor),
                        )
                      : Container(),
                  sizeVer(10),
                  bookRideEntity.driverPrice!.isNotEmpty || bookRideEntity.finalPrice!.isNotEmpty
                      ? Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                ButtonContainerWidget(
                                  text: "Cancel",
                                  width: 100,
                                  onTap: () {
                                    _cancelBookedRide(bookRide: bookRideEntity);
                                  },
                                ),
                                sizeHor(10),
                                ButtonContainerWidget(
                                  text: "Update",
                                  width: 100,
                                  onTap: () {
                                    _updatePassengerPrice(bookRideEntity: bookRideEntity);
                                    setState(() {
                                      _passengerProposalPriceController.text = "";
                                    });
                                  },
                                ),
                              ],
                            ),
                            sizeVer(10),
                            ButtonContainerWidget(
                              manualColor: true,
                              color: primaryColor,
                              text: "Accept Request",
                              isCenter: true,
                              onTap: () {
                                _passengerAcceptPrice(bookRide: bookRideEntity);
                              },
                            ),
                            sizeVer(20),
                          ],
                        )
                      : Container(),
                  bookRideEntity.driverPrice == "" && bookRideEntity.finalPrice == ""
                      ? Center(
                          child: Text(
                          "Waiting for Driver Response...",
                          style: TextStyle(fontSize: 16, color: Colors.red),
                        ))
                      : Container(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  _ridesInProgress({required BookRideEntity bookRideEntity}) {
    return StreamBuilder<List<UserEntity>>(
        stream: di.sl<GetSingleUserUseCase>().call(bookRideEntity.creatorId!),
        builder: (context, snapshot) {
          if (snapshot.hasData == false) {
            return Center(child: CircularProgressIndicator(),);
          }
          if (snapshot.data!.isEmpty) {
            return Container(width: 0, height: 0,);
          }
          final progressDriver = snapshot.data!.first;
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  width: double.infinity,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: Colors.black)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${bookRideEntity.driverId == widget.currentUser.uid ?progressDriver.accountType == AccountConst.driver?"Driver Price (${progressDriver.username})" : "Passenger Price (${progressDriver.username})" : "Your Price"}"),
                      sizeVer(10),
                      AbsorbPointer(
                        child: FormContainerWidget(
                          // controller: _proposeController,
                          height: 60,
                          inputType: TextInputType.number,
                          hintText: "${bookRideEntity.passengerPrice}",
                        ),
                      ),
                      sizeVer(10),
                      bookRideEntity.driverPrice!.isNotEmpty
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("${bookRideEntity.driverId == widget.currentUser.uid ? "Your Price" : "Driver Price"}"),
                                sizeVer(10),
                                AbsorbPointer(
                                  child: FormContainerWidget(
                                    // controller: _proposeController,
                                    height: 60,
                                    inputType: TextInputType.number,
                                    hintText: "${bookRideEntity.driverPrice}",
                                  ),
                                ),
                                sizeVer(10),
                              ],
                            )
                          : Container(),
                      Text("Final price"),
                      sizeVer(10),
                      AbsorbPointer(
                        child: FormContainerWidget(
                          // controller: _proposeController,
                          height: 60,
                          inputType: TextInputType.number,
                          hintText: "${bookRideEntity.finalPrice}",
                        ),
                      ),
                      sizeVer(10),
                      bookRideEntity.driverPrice == "" && bookRideEntity.finalPrice == ""
                          ? Center(
                              child: Text(
                              "Waiting for Driver Response...",
                              style: TextStyle(fontSize: 16, color: Colors.red),
                            ))
                          : Container(),
                      InkWell(
                        onTap: () async {
                          final permission = await LocationPermissions().requestPermissions();
                          if (permission == pr.PermissionStatus.granted) {
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (_) => TrackMapLocationWidget(
                                          bookRideEntity: bookRideEntity,
                                          currentUser: widget.currentUser,
                                        )));
                          } else {}
                        },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(
                              "${bookRideEntity.driverId == widget.currentUser.uid ? "Track The Passenger" : "Track The Driver"}",
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                            ),
                            Icon(Icons.arrow_forward_ios)
                          ],
                        ),
                      ),
                      sizeVer(10),
                      bookRideEntity.creatorId == widget.currentUser.uid && widget.currentUser.accountType == AccountConst.passenger
                          ? Center(
                              child: ButtonContainerWidget(
                              text: "Cancel Ride",
                              onTap: () {
                                _cancelBookedRide(bookRide: bookRideEntity);
                              },
                            ))
                          : Container(),
                      bookRideEntity.driverId == widget.currentUser.uid && widget.currentUser.accountType == AccountConst.driver
                          ? Center(
                              child: ButtonContainerWidget(
                                text: "Complete Ride",
                                onTap: () {
                                  _doCompleteBookedRide(bookRide: bookRideEntity);
                                },
                              ),
                            )
                          : Container(),
                      sizeVer(10),
                      Center(
                          child: Text(
                        "Ride is in Progress...",
                        style: TextStyle(fontSize: 16, color: primaryColor),
                      )),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      }
    );
  }

  _updatePassengerPrice({BookRideEntity? bookRideEntity}) {
    if (_passengerProposalPriceController.text.isEmpty) {
      toast("Propose some price to update!");
      return;
    }

    BlocProvider.of<BookRideCubit>(context)
        .getUpdateBookRide(
      bookRideEntity: BookRideEntity(bookRideId: bookRideEntity!.bookRideId, passengerPrice: _passengerProposalPriceController.text),
    )
        .then((value) {
      toast("Your price has been sent to the driver!");
      Future.delayed(Duration(seconds: 4)).then((value) {
        toast("Please wait for driver response");
      });
    });
  }

  _passengerAcceptPrice({BookRideEntity? bookRide}) {
    acceptPriceAlert(context, onDeletePostClickListener: () {
      BlocProvider.of<BookRideCubit>(context)
          .getUpdateBookRide(
        bookRideEntity: BookRideEntity(
          bookRideId: bookRide!.bookRideId,
          finalPrice: bookRide.driverPrice,
          priceAgreementStatus: BudgetAgreementStatus.agreed,
          bookingStatus: BookingStatusConst.inProgress,
        ),
      )
          .then((value) {
        toast("Request accept successful!");
        Navigator.pop(context);
        Future.delayed(Duration(seconds: 4)).then((value) {
          toast("Your Ride is in Progress");
        });
      });
    });
  }

  _cancelBookedRide({BookRideEntity? bookRide}) {
    cancelRideAlert(context, onDeletePostClickListener: () {
      BlocProvider.of<BookRideCubit>(context).getDeleteBookRide(bookRideEntity: BookRideEntity(bookRideId: bookRide!.bookRideId)).then((value) {
        Navigator.pop(context);
        toast("Booked ride cancelled!");
      });
    });
  }

  _doCompleteBookedRide({BookRideEntity? bookRide}) {
    completeRideAlert(context, onDeletePostClickListener: () {
      BlocProvider.of<BookRideCubit>(context)
          .getUpdateBookRide(
              bookRideEntity: BookRideEntity(
        bookRideId: bookRide!.bookRideId,
        bookingStatus: BookingStatusConst.complete,
      ))
          .then((value) {
        Navigator.pop(context);
        toast("Booked ride is Completed!");
        Future.delayed(Duration(seconds: 4)).then((value) {
          toast("Please check the Complete Rides Tab");
        });
      });
    });
  }
}
