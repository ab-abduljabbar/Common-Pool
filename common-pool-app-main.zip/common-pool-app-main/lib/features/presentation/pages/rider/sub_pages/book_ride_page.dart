import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/single_user/single_user_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/container_button_no_icon_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/geocoder.dart';
import 'package:location_permissions/location_permissions.dart';
import 'package:location_permissions/location_permissions.dart' as pr;

import '../../../widgets/form_container_widget.dart';
import '../../../widgets/map_location_picker_widget.dart';


class BookRidePage extends StatefulWidget {
  final UserEntity driverEntity;
  final Coordinates passengerLocation;

  const BookRidePage({Key? key, required this.driverEntity, required this.passengerLocation}) : super(key: key);

  @override
  State<BookRidePage> createState() => _BookRidePageState();
}

class _BookRidePageState extends State<BookRidePage> {
  TextEditingController _destinationAddressController = TextEditingController();
  Coordinates? _destinationLocationLocationLatLong;
  TextEditingController _passengerAddressController = TextEditingController();
  TextEditingController _proposeController = TextEditingController();
  Coordinates? _passengerLocationLocationLatLong;

  @override
  void initState() {
    _passengerLocationLocationLatLong = widget.passengerLocation;
    _updateLocation();
    super.initState();
  }

  _updateLocation() async {
    final location = await _coordinatesToAddress(widget.passengerLocation);
    _passengerAddressController.value = TextEditingValue(text: "$location");
  }

  @override
  void dispose() {
    _destinationAddressController.dispose();
    _passengerAddressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<SingleUserCubit, SingleUserState>(
          builder: (context, singleUserState) {
            if (singleUserState is SingleUserLoaded) {
              final currentUser = singleUserState.user;

              return Container(
                margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Icon(Icons.arrow_back_ios),
                    ),
                    sizeVer(10),
                    MainTextWidget(
                      text: "Book Ride",
                      dotColor: primaryColor,
                    ),
                    Divider(
                      color: Colors.grey,
                    ),
                    sizeVer(10),
                    Text("Where you want to go?"),
                    sizeVer(10),
                    InkWell(
                      onTap: () async {
                        final permission = await LocationPermissions().requestPermissions();
                        if (permission == pr.PermissionStatus.granted) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => MapLocationPickerWidget(
                                        onLocationListener: (Coordinates coordinates, String address, String adminArea) {
                                          setState(() {
                                            _destinationAddressController.value = TextEditingValue(text: "$address");
                                            _destinationLocationLocationLatLong = coordinates;
                                          });
                                        },
                                      )));
                        } else {}
                      },
                      child: Container(
                        height: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(8), bottomLeft: Radius.circular(8), topRight: Radius.circular(8), bottomRight: Radius.circular(8)),
                            border: Border.all(width: 1, color: Colors.grey)),
                        child: Row(
                          children: [
                            Expanded(
                              child: AbsorbPointer(
                                child: TextFormField(
                                  controller: _destinationAddressController,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                      border: InputBorder.none,
                                      prefixIcon: Icon(Icons.add_location_alt_outlined),
                                      hintText: "Where you want to go?",
                                      contentPadding: EdgeInsets.only(top: 15, left: 5)),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Icon(Icons.add_location_outlined),
                            SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                    sizeVer(10),
                    Text("Your Location"),
                    sizeVer(10),
                    InkWell(
                      onTap: () async {
                        final permission = await LocationPermissions().requestPermissions();
                        if (permission == pr.PermissionStatus.granted) {
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) => MapLocationPickerWidget(
                                        onLocationListener: (Coordinates coordinates, String address, String adminArea) {
                                          setState(() {
                                            _passengerAddressController.value = TextEditingValue(text: "$address");
                                            _passengerLocationLocationLatLong = coordinates;
                                          });
                                        },
                                      )));
                        } else {}
                      },
                      child: Container(
                        height: 50,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(8), bottomLeft: Radius.circular(8), topRight: Radius.circular(8), bottomRight: Radius.circular(8)),
                            border: Border.all(width: 1, color: Colors.grey)),
                        child: Row(
                          children: [
                            Expanded(
                              child: AbsorbPointer(
                                child: TextFormField(
                                  controller: _passengerAddressController,
                                  keyboardType: TextInputType.text,
                                  decoration: InputDecoration(
                                      border: InputBorder.none, prefixIcon: Icon(Icons.add_location_alt_outlined), hintText: "Your Address", contentPadding: EdgeInsets.only(top: 15, left: 5)),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 10,
                            ),
                            Icon(Icons.add_location_outlined),
                            SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                      ),
                    ),
                    sizeVer(10),
                    FormContainerWidget(
                      controller: _proposeController,
                      height: 60,
                      inputType: TextInputType.number,
                      hintText: "propose your price e.g (2000 PKR)",
                    ),
                    ContainerButtonNoIconWidget(
                      title: "Book Now",
                      color: primaryColor,
                      onClickListener: () {
                        if (_destinationAddressController.text.isEmpty){
                          toast("Select destination location");
                          return;
                        }
                        if (_proposeController.text.isEmpty) {
                          toast("Enter price");
                          return;
                        }
                        BlocProvider.of<BookRideCubit>(context).getPostBookRide(
                            bookRideEntity: BookRideEntity(
                          bookingStatus: BookingStatusConst.waiting,
                          destination: GeoPoint(_destinationLocationLocationLatLong!.latitude!, _destinationLocationLocationLatLong!.longitude),
                          dateTime: Timestamp.now(),
                          driverLocation: widget.driverEntity.locationPoint,
                          creatorId: currentUser.uid,
                              driverId: widget.driverEntity.uid,
                              address: "",
                              currentLocation: GeoPoint(_passengerLocationLocationLatLong!.latitude!, _passengerLocationLocationLatLong!.longitude),
                              driverPrice: "",
                              finalPrice: "",
                              priceAgreementStatus: BudgetAgreementStatus.notAgreeYet,
                              passengerPrice: _proposeController.text,
                        )).then((value) {
                          setState(() {
                            Navigator.pop(context);
                            Navigator.pop(context);
                            if (widget.driverEntity.accountType == AccountConst.driver) {
                              toast("Your ride book successful");
                              Future.delayed(Duration(seconds: 2)).then((value) => toast("Wait for driver response!"));
                            } else {
                              toast("Your ride book successful");
                            }
                          });
                        });
                      },
                    )
                  ],
                ),
              );
            }

            return centerProgressBarIndicator();
          },
        ),
      ),
    );
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address = await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;

    return "${newAddress.addressLine}";
  }
}
