import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/data/models/book_ride_model.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_current_uid_usecase.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/feedback/feedback_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/user/user_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:location_permissions/location_permissions.dart' as pr;
import 'package:location_permissions/location_permissions.dart';

import 'package:common_pool_app/injection_container.dart' as di;

import '../../../../domain/use_cases/user_usecases/get_single_user_usecase.dart';
import '../../../widgets/form_container_widget.dart';

class CompleteRidesPage extends StatefulWidget {
  final UserEntity currentUser;

  const CompleteRidesPage({Key? key, required this.currentUser}) : super(key: key);

  @override
  State<CompleteRidesPage> createState() => _CompleteRidesPageState();
}

class _CompleteRidesPageState extends State<CompleteRidesPage> {
  TextEditingController _passengerCurrentAddressController = TextEditingController();
  TextEditingController _passengerDestinationController = TextEditingController();
  TextEditingController _driverProposalPriceController = TextEditingController();
  TextEditingController _feedbackController = TextEditingController();
  Coordinates? _passengerLocationLocationLatLong;
  Coordinates? _destinationLocationLocationLatLong;

  String _currentUid = "";

  num _totalRating = 1;

  @override
  void initState() {
    di.sl<GetCurrentUidUseCase>().call().then((value) {
      _currentUid = value;
    });
    BlocProvider.of<FeedbackCubit>(context).getFeedbacks(feedbackEntity: FeedbackEntity(creatorId: widget.currentUser.uid));
    super.initState();
  }

  @override
  void dispose() {
    _driverProposalPriceController.dispose();
    _passengerCurrentAddressController.dispose();
    _passengerDestinationController.dispose();
    _feedbackController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<BookRideCubit, BookRideState>(
        builder: (context, bookRideState) {
          if (bookRideState is BookRideFailure) {
            return Center(
              child: Text("Some Error Occured"),
            );
          }
          if (bookRideState is BookRideLoaded) {
            return BlocBuilder<FeedbackCubit, FeedbackState>(
              builder: (context, feedbackState) {
                if (feedbackState is FeedbackLoaded) {
                  final bookRide = bookRideState.bookRideData
                      .where((element) =>
                          element.creatorId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.completeFeedback ||
                          element.driverId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.completeFeedback ||
                          element.creatorId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.complete ||
                          element.driverId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.complete)
                      .toList();
                  return bookRide.isEmpty
                      ? Align(
                          alignment: Alignment.topCenter,
                          child: Text(
                            "No Completed Rides Yet",
                            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                          ),
                        ) : ListView.builder(
                    itemCount: bookRide.length,
                    itemBuilder: (context, index) {
                      return _bodyWidget(bookRideEntity: bookRide[index]);
                    },
                  );
                  /// [Deprecated]
                      // : feedbackState.feedbacks.isEmpty
                      //     ? ListView.builder(
                      //         itemCount: bookRide.length,
                      //         itemBuilder: (context, index) {
                      //           return _bodyWidget(bookRideEntity: bookRide[index]);
                      //         },
                      //       )
                      //     : ListView.builder(
                      //         itemCount: bookRide.length,
                      //         itemBuilder: (context, index) {
                      //           return _bodyWidget(bookRideEntity: bookRide[index], feedbackEntity: feedbackState.feedbacks[index]);
                      //         },
                      //       );

                }
                return Center(
                  child: CircularProgressIndicator(),
                );
              },
            );
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }

  _bodyWidget({required BookRideEntity bookRideEntity}) {
    if (widget.currentUser.uid == bookRideEntity.driverId && widget.currentUser.accountType == AccountConst.driver) {
      return _driverViewCompleteRides(bookRideEntity: bookRideEntity);
    } else if (widget.currentUser.uid == bookRideEntity.creatorId && widget.currentUser.accountType == AccountConst.passenger) {
      return _passengerViewCompleteRides(bookRideEntity: bookRideEntity);
    } else {
      return Center(
        child: Align(alignment: Alignment.topCenter, child: Text("No Completed Rides Yet", style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18))),
      );
    }
  }

  _passengerViewCompleteRides({required BookRideEntity bookRideEntity}) {
    return StreamBuilder<List<UserEntity>>(
      stream: di.sl<GetSingleUserUseCase>().call(bookRideEntity.driverId!),
      builder: (context, snapshot) {
        if (snapshot.hasData == false) {
          return Center(child: CircularProgressIndicator(),);
        }
        if (snapshot.data!.isEmpty) {
          return Container(width: 0, height: 0,);
        }
        final completedDriver = snapshot.data!.first;
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  width: double.infinity,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: Colors.black)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                          child: Text(
                        "(${completedDriver.username}) Driver Moved You",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 22, color: primaryColor, fontWeight: FontWeight.bold),
                      )),
                      sizeVer(10),
                      Center(child: Text("--- TO YOUR DESTINATION ---", textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
                      sizeVer(10),
                      Text(
                        "How was your Experience with Common Pool?",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600, color: primaryColor),
                      ),
                      sizeVer(15),
                      Center(
                          child: Text(
                        "Give Feedback to the Driver",
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                      )),
                      sizeVer(15),
                      Center(
                        child: ButtonContainerWidget(
                          manualColor: true,
                          color: bookRideEntity.bookingStatus == BookingStatusConst.completeFeedback ? primaryColor.withOpacity(.4) : primaryColor,
                          text: "Feedback",
                          onTap: () {
                            if (bookRideEntity.bookingStatus == BookingStatusConst.complete) {
                              feedbackAlert(
                                context: context,
                                feedbackController: _feedbackController,
                                onTap: () {
                                  if (_feedbackController.text.isEmpty) {
                                    toast("Enter Review");
                                    return;
                                  }
                                  BlocProvider.of<FeedbackCubit>(context)
                                      .addFeedback(
                                          feedbackEntity: FeedbackEntity(
                                    createAt: Timestamp.now(),
                                    totalRating: _totalRating,
                                    review: _feedbackController.text,
                                    feedbackId: bookRideEntity.driverId,
                                    creatorId: bookRideEntity.creatorId,
                                    driverId: bookRideEntity.driverId,
                                  ))
                                      .then(
                                    (value) {
                                        BlocProvider.of<BookRideCubit>(context)
                                            .getUpdateBookRide(
                                          bookRideEntity: BookRideEntity(bookRideId: bookRideEntity.bookRideId, bookingStatus: BookingStatusConst.completeFeedback),
                                        )
                                            .then(
                                          (value) {
                                            toast("Thank you for your feedback!");
                                            setState(() {
                                              _feedbackController.text = "";
                                              _totalRating =0;

                                            });
                                            Navigator.pop(context);
                                          },
                                        );

                                    },
                                  );
                                },
                              );
                              return;
                            }
                            if (bookRideEntity.bookingStatus == BookingStatusConst.completeFeedback) {
                              toast("Feedback is already sent!");
                              return;
                            }
                          },
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      }
    );
  }

  _driverViewCompleteRides({required BookRideEntity bookRideEntity}) {
    return StreamBuilder<List<UserEntity>>(
        stream: di.sl<GetSingleUserUseCase>().call(bookRideEntity.creatorId!),
      builder: (context, snapshot) {
        if (snapshot.hasData == false) {
          return Center(child: CircularProgressIndicator(),);
        }
        if (snapshot.data!.isEmpty) {
          return Container(width: 0, height: 0,);
        }
        final completedPassenger = snapshot.data!.first;
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  width: double.infinity,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: Colors.black)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Text(
                          "You Moved (${completedPassenger.username}) Passenger",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 25, color: primaryColor, fontWeight: FontWeight.bold),
                        ),
                      ),
                      sizeVer(15),
                      Center(
                        child: Text(
                          "To his destination",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ),
                      sizeVer(10),
                      Center(
                        child: Text(
                          "Thanks!",
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: primaryColor),
                        ),
                      ),
                      /// [Deprecated]
                      // widget.currentUser.totalRating == 0
                      //     ? Center(
                      //         child: Text(
                      //           "Wait for a great feedback\nfrom Passenger", textAlign: TextAlign.center,
                      //           style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      //         ),
                      //       )
                      //     : Column(
                      //         children: [
                      //           Text(
                      //             "Passenger Respond with these Expressions!",
                      //             style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      //           ),
                      //           sizeVer(10),
                      //           Icon(Icons.arrow_downward, color: primaryColor,),
                      //           sizeVer(10),
                      //           Container(
                      //             padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                      //             width: double.infinity,
                      //             decoration: BoxDecoration(
                      //               border: Border.all(color: primaryColor, width: 1),
                      //               borderRadius: BorderRadius.circular(10),
                      //             ),
                      //             child: Column(
                      //               children: [
                      //                 Text("${feedbackEntity!.review}", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
                      //                 sizeVer(10),
                      //                 Center(
                      //                   child: RatingBarIndicator(
                      //                     rating: feedbackEntity.totalRating!.toDouble(),
                      //                     itemBuilder: (context, index) => Icon(
                      //                       Icons.star,
                      //                       color: Colors.amber,
                      //                     ),
                      //                     itemCount: 5,
                      //                     itemSize: 40.0,
                      //                     direction: Axis.horizontal,
                      //                   ),)
                      //               ],
                      //             ),
                      //           )
                      //         ],
                      //       ),
                      sizeVer(10),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      }
    );
  }

  feedbackAlert({required BuildContext context, required TextEditingController feedbackController, onTap}) {
    // set up the button
    Widget cancelButton = TextButton(
      child: Text("Cancel"),
      onPressed: () {
        Navigator.pop(context);
      },
    );
    Widget yesButton = TextButton(
      child: Text("Yes"),
      onPressed: onTap,
    );

    // set up the AlertDialog
    AlertDialog alert = AlertDialog(
      title: Text("Give feedback to the Driver"),
      content: Container(
        height: 160,
        child: SingleChildScrollView(
          child: Column(
            children: [
              sizeVer(10),
              FormContainerWidget(controller: feedbackController, hintText: "How was your experience"),
              sizeVer(10),
              RatingBar.builder(
                initialRating: 1,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: false,
                itemCount: 5,
                itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                itemBuilder: (context, _) => Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                onRatingUpdate: (rating) {
                  setState(() {
                    _totalRating = rating;
                  });
                },
              ),
            ],
          ),
        ),
      ),
      actions: [cancelButton, yesButton],
    );
    // show the dialog
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return alert;
      },
    );

    Future<String> _coordinatesToAddress(Coordinates coordinates) async {
      final address = await Geocoder.local.findAddressesFromCoordinates(coordinates);
      final newAddress = address.first;
      return "${newAddress.locality}";
    }
  }

  _returnNull() {
    toast("Feedback is already sent to the driver!");
  }
}
