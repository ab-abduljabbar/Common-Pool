import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/data/models/book_ride_model.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_current_uid_usecase.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/alert/accept_price_alert.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geocoder/model.dart';
import 'package:location_permissions/location_permissions.dart' as pr;
import 'package:location_permissions/location_permissions.dart';

import 'package:common_pool_app/injection_container.dart' as di;

import '../../../../domain/use_cases/user_usecases/get_single_user_usecase.dart';
import '../../../widgets/alert/cancel_ride_alert.dart';
import '../../../widgets/form_container_widget.dart';

class WaitingRidesPage extends StatefulWidget {
  final UserEntity currentUser;

  const WaitingRidesPage({Key? key, required this.currentUser}) : super(key: key);

  @override
  State<WaitingRidesPage> createState() => _WaitingRidesPageState();
}

class _WaitingRidesPageState extends State<WaitingRidesPage> {
  TextEditingController _passengerCurrentAddressController = TextEditingController();
  TextEditingController _passengerDestinationController = TextEditingController();
  TextEditingController _driverProposalPriceController = TextEditingController();
  Coordinates? _passengerLocationLocationLatLong;
  Coordinates? _destinationLocationLocationLatLong;

  String _currentUid = "";

  // _updateLocation() async {
  //   final location = await _coordinatesToAddress(_passengerLocationLocationLatLong!);
  //   _passengerCurrentAddressController.value = TextEditingValue(text: "$location");
  // }

  @override
  void initState() {
    di.sl<GetCurrentUidUseCase>().call().then((value) {
      _currentUid = value;
    });
    // _updateLocation();
    super.initState();
  }

  @override
  void dispose() {
    _driverProposalPriceController.dispose();
    _passengerCurrentAddressController.dispose();
    _passengerDestinationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<BookRideCubit, BookRideState>(
        builder: (context, bookRideState) {
          if (bookRideState is BookRideFailure) {
            return Center(
              child: Text("Some Error Occured"),
            );
          }
          if (bookRideState is BookRideLoaded) {
            final bookRide = bookRideState.bookRideData.where((element) => element.driverId == widget.currentUser.uid && element.bookingStatus == BookingStatusConst.waiting).toList();
            return bookRide.isEmpty
                ? Align(
                    alignment: Alignment.topCenter,
                    child: Text(
                      "No Rides Are Waiting Yet",
                      style: TextStyle(fontWeight: FontWeight.w600, fontSize: 18),
                    ),
                  )
                : ListView.builder(
                    itemCount: bookRide.length,
                    itemBuilder: (context, index) {
                      return _bodyWidget(bookRideEntity: bookRide[index]);
                    });
          }
          return Center(
            child: CircularProgressIndicator(),
          );
        },
      ),
    );
  }

  _bodyWidget({required BookRideEntity bookRideEntity}) {
    return StreamBuilder<List<UserEntity>>(
      stream: di.sl<GetSingleUserUseCase>().call(bookRideEntity.creatorId!),
      builder: (context, snapshot) {
        if (snapshot.hasData == false) {
          return Center(child: CircularProgressIndicator(),);
        }
        if (snapshot.data!.isEmpty) {
          return Container(width: 0, height: 0,);
        }
        final waitingUser = snapshot.data!.first;
        return Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                  width: double.infinity,
                  decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(width: 1, color: Colors.black)),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("${waitingUser.username} (${waitingUser.accountType}) Price"),
                      sizeVer(10),
                      AbsorbPointer(
                        child: FormContainerWidget(
                          // controller: _proposeController,
                          height: 60,
                          hintText: "${bookRideEntity.passengerPrice}",
                        ),
                      ),
                      sizeVer(10),
                      FormContainerWidget(
                        controller: _driverProposalPriceController,
                        height: 60,
                        inputType: TextInputType.number,
                        hintText: "propose your price (optional)",
                      ),
                      sizeVer(5),
                      bookRideEntity.priceAgreementStatus == BudgetAgreementStatus.notAgreeYet
                          ? Text(
                              "Propose your price if you are not agree with Passenger price.",
                              textAlign: TextAlign.center,
                              style: TextStyle(fontSize: 16, color: primaryColor),
                            )
                          : Container(),
                      sizeVer(10),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          ButtonContainerWidget(
                            text: "Cancel",
                            width: 100,
                            onTap: () {
                              _cancelBookedRide(bookRide: bookRideEntity);
                            },
                          ),
                          sizeHor(10),
                          ButtonContainerWidget(
                            text: "Update",
                            width: 100,
                            onTap: () {
                              _updateDriverPrice(bookRide: bookRideEntity);
                              setState(() {
                                _driverProposalPriceController.text = "";
                              });
                            },
                          ),
                        ],
                      ),
                      sizeVer(10),
                      ButtonContainerWidget(
                        manualColor: true,
                        color: primaryColor,
                        text: "Accept Request",
                        isCenter: true,
                        onTap: () {
                          _driverAcceptPrice(bookRide: bookRideEntity);
                        },
                      ),
                    ],
                  ),
                )
              ],
            ),
          ),
        );
      }
    );
  }

  _updateDriverPrice({BookRideEntity? bookRide}) {
    if (_driverProposalPriceController.text.isEmpty) {
      toast("Propose price to update!");
      return;
    }
    BlocProvider.of<BookRideCubit>(context)
        .getUpdateBookRide(
      bookRideEntity: BookRideEntity(
        bookRideId: bookRide!.bookRideId,
        driverPrice: _driverProposalPriceController.text,
      ),
    )
        .then((value) {
      toast("Your price has been sent to the passenger!");
      Future.delayed(Duration(seconds: 4)).then((value) {
        toast("Please wait for passenger response");
      });
    });
  }

  _driverAcceptPrice({BookRideEntity? bookRide}) {
    acceptPriceAlert(context, onDeletePostClickListener: () {
      BlocProvider.of<BookRideCubit>(context)
          .getUpdateBookRide(
        bookRideEntity:
            BookRideEntity(bookRideId: bookRide!.bookRideId, finalPrice: bookRide.passengerPrice, priceAgreementStatus: BudgetAgreementStatus.agreed, bookingStatus: BookingStatusConst.inProgress),
      )
          .then((value) {
        toast("Request accept successful!");
        Navigator.pop(context);
        Future.delayed(Duration(seconds: 4)).then((value) {
          toast("Please check rides in progress tab");
        });
      });
    });
  }

  _cancelBookedRide({BookRideEntity? bookRide}) {
    cancelRideAlert(context, onDeletePostClickListener: () {
      BlocProvider.of<BookRideCubit>(context).getDeleteBookRide(bookRideEntity: BookRideEntity(bookRideId: bookRide!.bookRideId)).then((value) {
        Navigator.pop(context);
        toast("Booked ride cancelled!");
      });
    });
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address = await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;
    return "${newAddress.locality}";
  }
}
