import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_single_user_usecase.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

import '../../cubit/feedback/feedback_cubit.dart';
import 'package:common_pool_app/injection_container.dart' as di;

class FeedbackPage extends StatefulWidget {
  final UserEntity driver;


  const FeedbackPage({Key? key, required this.driver}) : super(key: key);

  @override
  State<FeedbackPage> createState() => _FeedbackPageState();
}

class _FeedbackPageState extends State<FeedbackPage> {
  @override
  void initState() {
    BlocProvider.of<FeedbackCubit>(context).getFeedbacks(feedbackEntity: FeedbackEntity(feedbackId: widget.driver.uid));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: BlocBuilder<FeedbackCubit, FeedbackState>(
          builder: (context, feedbackState) {
            if (feedbackState is FeedbackLoaded) {
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    InkWell(
                        onTap: () {
                          Navigator.pop(context);
                        },
                        child: Icon(Icons.arrow_back_ios)),
                    MainTextWidget(text: "Driver Feedbacks", size: 40),
                    sizeVer(10),
                    Divider(
                      color: Colors.grey,
                    ),
                    sizeVer(10),
                    Expanded(
                      child: feedbackState.feedbacks.isEmpty
                          ? Align(
                              alignment: Alignment.topCenter,
                              child: Text(
                                "No Feedbacks yet",
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            )
                          : ListView.builder(
                              itemCount: feedbackState.feedbacks.length,
                              itemBuilder: (context, index) {
                                return StreamBuilder<List<UserEntity>>(
                                  stream: di.sl<GetSingleUserUseCase>().call(feedbackState.feedbacks[index].creatorId!),
                                  builder: (context, snapshot) {
                                    if (snapshot.hasData == false) {
                                      return Center(child: CircularProgressIndicator(),);
                                    }
                                    if (snapshot.data!.isEmpty) {
                                      return Container(width: 0, height: 0,);
                                    }
                                    final feedbackUser = snapshot.data!.first;
                                    return Column(
                                      children: [
                                        Container(
                                          width: double.infinity,
                                          margin: EdgeInsets.symmetric(vertical: 8),
                                          decoration: BoxDecoration(
                                            border: Border.all(width: 1),
                                            borderRadius: BorderRadius.circular(10)
                                          ),
                                          child: Padding(
                                            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
                                            child: Column(
                                              children: [
                                                Text("${feedbackUser.username} Passenger Expressions!", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),),
                                                sizeVer(15),
                                               Container(
                                                 width: double.infinity,
                                                 decoration: BoxDecoration(
                                                   border: Border.all(width: 1, color: primaryColor),
                                                   borderRadius: BorderRadius.circular(10),
                                                 ),
                                                 child: Padding(
                                                   padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 10),
                                                   child: Column(
                                                     children: [
                                                       Text("${feedbackState.feedbacks[index].review}", style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),),
                                                       sizeVer(10),
                                                       Center(
                                                         child: RatingBarIndicator(
                                                           rating: feedbackState.feedbacks[index].totalRating!.toDouble(),
                                                           itemBuilder: (context, index) => Icon(
                                                             Icons.star,
                                                             color: Colors.amber,
                                                           ),
                                                           itemCount: 5,
                                                           itemSize: 40.0,
                                                           direction: Axis.horizontal,
                                                         ),)
                                                     ],
                                                   ),
                                                 ),
                                               )
                                              ],
                                            ),
                                          ),
                                        ),
                                      ],
                                    );
                                  }
                                );
                              },
                            ),
                    )
                  ],
                ),
              );
            }
            return Center(
              child: CircularProgressIndicator(),
            );
          },
        ),
      ),
    );
  }
}

// return feedbackState.feedbacks[index].driverId == widget.userEntity.uid ? Align(
// alignment: Alignment.topCenter,
// child: Text(
// "No Feedbacks yet",
// style: TextStyle(
// fontSize: 16,
// fontWeight: FontWeight.bold,
// ),
// ),
// ) :
