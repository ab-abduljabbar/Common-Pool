
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/model.dart';
import 'package:image_picker/image_picker.dart';
import 'package:location_permissions/location_permissions.dart';
import 'package:location_permissions/location_permissions.dart' as pr;

import '../../../../data/data_sources/remote/firebase_storage_provider.dart';
import '../../../cubit/user/user_cubit.dart';
import '../../../widgets/map_location_picker_widget.dart';
import '../widgets/profile_avatar_widget.dart';
import '../widgets/profile_single_item_widget.dart';

class EditProfilePage extends StatefulWidget {
  final UserEntity userEntity;
  const EditProfilePage({Key? key, required this.userEntity}) : super(key: key);

  @override
  State<EditProfilePage> createState() => _EditProfilePageState();
}

class _EditProfilePageState extends State<EditProfilePage> {
  TextEditingController? _usernameController;
  TextEditingController? _phoneController;
  TextEditingController? _carController;
  TextEditingController? _carModelController;
  TextEditingController? _numberOfSeatsController;
  TextEditingController? _addressController;
  TextEditingController? _aboutController;
  TextEditingController? _accountTypeController;
  Coordinates? _pickUpLocationLatLong;

  File? _image;

  Future selectImage() async {
    try {
      final pickedFile =
      await ImagePicker.platform.getImage(source: ImageSource.gallery);

      setState(() {
        if (pickedFile != null) {
          _image = File(pickedFile.path);
        } else {
          print('No image selected.');
        }
      });
    } catch (e) {
      print("error $e");
    }
  }

  @override
  void initState() {
    _usernameController = TextEditingController(text: widget.userEntity.username);
    _phoneController = TextEditingController(text: widget.userEntity.phone);
    _addressController = TextEditingController(text: widget.userEntity.address);
    _aboutController = TextEditingController(text: widget.userEntity.about);
    _carController = TextEditingController(text: widget.userEntity.car);
    _carModelController = TextEditingController(text: widget.userEntity.carModel);
    _numberOfSeatsController = TextEditingController(text: widget.userEntity.numberOfSeats);
    _accountTypeController = TextEditingController(text: widget.userEntity.accountType);
    super.initState();
  }

  @override
  void dispose() {
    _usernameController!.dispose();
    _phoneController!.dispose();
    _carController!.dispose();
    _carModelController!.dispose();
    _numberOfSeatsController!.dispose();
    _addressController!.dispose();
    _aboutController!.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.arrow_back_ios)),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    MainTextWidget(
                      text: "Editing",
                      size: 60,
                    ),
                    ProfileAvatarWidget(isEditable: true, image: _image, imageUrl: widget.userEntity.photoUrl, onEditListener: selectImage),
                    InkWell(
                      onTap: () {
                        _updateProfile();
                      },
                      child: Row(
                        children: [
                          Icon(
                            Icons.save,
                            size: 30
                          ),
                          sizeHor(2),
                          Text(
                            "Save",
                            style: TextStyle(fontSize: 18),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
                Divider(
                  color: Colors.grey,
                ),
                sizeVer(10),
                ProfileSingleItemWidget(title: "Name", isEditable: true, controller: _usernameController),
                sizeVer(10),
                Divider(
                  color: Colors.grey,
                ),
                sizeVer(10),
                ProfileSingleItemWidget(title: "Phone", isEditable: true, controller: _phoneController,),
                sizeVer(10),
                Divider(
                  color: Colors.grey,
                ),
                sizeVer(10),
                widget.userEntity.accountType == "driver" ? Column(
                  children: [
                    ProfileSingleItemWidget(title: "Car", isEditable: true, controller: _carController,),
                    sizeVer(10),
                    Divider(
                      color: Colors.grey,
                    ),
                    sizeVer(10),
                    ProfileSingleItemWidget(title: "Car Model", isEditable: true, controller: _carModelController,),
                    sizeVer(10),
                    Divider(
                      color: Colors.grey,
                    ),
                    sizeVer(10),
                    ProfileSingleItemWidget(title: "Number of seats", isEditable: true, controller: _numberOfSeatsController,),
                    sizeVer(10),
                    Divider(
                      color: Colors.grey,
                    ),
                    sizeVer(10),
                  ],
                ) : Container(),
                ProfileSingleItemWidget(title: "About", isEditable: true, controller: _aboutController),
                sizeVer(10),
                Divider(
                  color: Colors.grey,
                ),
                sizeVer(10),
            InkWell(
              onTap: ()async{
                final permission = await LocationPermissions().requestPermissions();
                if (permission == pr.PermissionStatus.granted) {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => MapLocationPickerWidget(
                    onLocationListener:
                        (Coordinates coordinates,
                        String address,
                        String adminArea) {
                      setState(() {
                        _addressController!.value =
                            TextEditingValue(
                                text: "$address");
                        _pickUpLocationLatLong=coordinates;
                      });
                    },
                  )));
                } else {}
              },
              child: Container(
                height: 50,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(8),
                        bottomLeft: Radius.circular(8),
                        topRight: Radius.circular(8),
                        bottomRight: Radius.circular(8)),
                    border:
                    Border.all(width: 1, color: Colors.grey)),
                child: Row(
                  children: [
                    Expanded(
                      child: AbsorbPointer(
                        child: TextFormField(
                          controller: _addressController,
                          keyboardType: TextInputType.text,
                          decoration: InputDecoration(
                              border: InputBorder.none,
                              prefixIcon: Icon(
                                  Icons.add_location_alt_outlined),
                              hintText: "Address",
                              contentPadding: EdgeInsets.only(
                                  top: 15, left: 5)),
                        ),
                      ),
                    ),
                    SizedBox(
                      width: 10,
                    ),
                    Icon(Icons.add_location_outlined),
                    SizedBox(
                      width: 10,
                    ),
                  ],
                ),
              ),
            ),
                sizeVer(10),
                Divider(
                  color: Colors.grey,
                ),

                sizeVer(10),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _updateProfile() {
    // Validating Username
    if (_usernameController!.text.isEmpty) {
      toast("Username cannot be empty");
      return;
    } else if (_usernameController!.text.length > 12) {
      toast("Must be at least 12 characters");
      return;
    }

    // Validating Phone
    if (_phoneController!.text.isEmpty) {
      toast("Phone Number cannot be empty");
      return;
    } else if (_phoneController!.text.length > 18) {
      toast("Must be at least 18 characters");
      return;

    }

    // Validating Car
    if (_carController!.text.isEmpty) {
      toast("Driver must have a Car so it cannot be empty");
      return;
    } else if (_phoneController!.text.length > 25) {
      toast("Must be at least 25 characters");
      return;

    }

    // Validating Car Model
    if (_carModelController!.text.isEmpty) {
      toast("Car must have a Model so it cannot be empty");
      return;
    } else if (_carModelController!.text.length > 25) {
      toast("Must be at least 25 characters");
      return;

    }

    // Validating Number of Seats
    if (_numberOfSeatsController!.text.isEmpty) {
      toast("Car must have seats so it cannot be empty");
      return;
    } else if (_numberOfSeatsController!.text.length > 1) {
      toast("Must be at least 1 character");
      return;

    }

    // Validating About
    if (_numberOfSeatsController!.text.length > 100) {
      toast("Must be at least 100 characters");
      return;
    }




    if (_image == null) {
      _updateData(imageUrl: null);
    } else {
      StorageProviderRemoteDataSource.uploadFile(file: _image!, onComplete: (value) {}).then((value) {
        print("profileUrl");
        _updateData(imageUrl: value);
      });
    }
  }

  void _updateData({String? imageUrl}) {
    BlocProvider.of<UserCubit>(context).getUpdateUser(
        UserEntity(
            uid: widget.userEntity.uid,
            username: _usernameController!.text,
            phone: _phoneController!.text,
            numberOfSeats: _numberOfSeatsController!.text,
            createAt: Timestamp.now(),
            carModel: _carModelController!.text,
            car: _carController!.text,
            address: _addressController!.text,
            about: _aboutController!.text,
            photoUrl: imageUrl
        )
    ).then((value) {
      toast("Profile Updated");
      Navigator.pop(context);
    });
  }
}



