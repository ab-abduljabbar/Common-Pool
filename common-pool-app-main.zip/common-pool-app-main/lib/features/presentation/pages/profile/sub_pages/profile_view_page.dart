
import 'package:common_pool_app/features/presentation/cubit/auth/auth_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../../../../../consts.dart';
import '../../../../domain/entities/user_entity.dart';
import '../widgets/profile_avatar_widget.dart';
import '../widgets/profile_single_item_widget.dart';

class ViewProfilePage extends StatelessWidget {
  final UserEntity userEntity;
  const ViewProfilePage({Key? key, required this.userEntity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        body: Container(
          margin: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                InkWell(
                    onTap: () {
                      Navigator.pop(context);
                    },
                    child: Icon(Icons.arrow_back_ios)),
                Padding(
                  padding: const EdgeInsets.only(right: 8.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      MainTextWidget(text: "Driver Profile", size: 50),
                      ProfileAvatarWidget(imageUrl: userEntity.photoUrl),
                    ],
                  ),
                ),
                Divider(color: Colors.grey,),
                sizeVer(10),
                ProfileSingleItemWidget(title: "Name", value: "${userEntity.username} (${userEntity.accountType})"),
                sizeVer(10),
                Divider(color: Colors.grey,),
                sizeVer(10),
                ProfileSingleItemWidget(title: "Phone", value: "${userEntity.phone} "),
                sizeVer(10),
                Divider(color: Colors.grey,),
                sizeVer(10),
                userEntity.accountType == "driver" ?Column(
                  children: [
                    ProfileSingleItemWidget(title: "Car", value: "${userEntity.car} "),
                    sizeVer(10),
                    Divider(color: Colors.grey,),
                    sizeVer(10),
                    ProfileSingleItemWidget(title: "Car Model", value: "${userEntity.carModel} "),
                    sizeVer(10),
                    Divider(color: Colors.grey,),
                    sizeVer(10),
                    ProfileSingleItemWidget(title: "Number of seats", value: "${userEntity.numberOfSeats} "),
                    sizeVer(10),
                    Divider(color: Colors.grey,),
                    sizeVer(10),
                  ],
                ) : Container(),
                ProfileSingleItemWidget(title: "About", value: "${userEntity.about == "" ? "Empty" : userEntity.about} "),
                sizeVer(10),
                Divider(color: Colors.grey,),
                sizeVer(10),
                ProfileSingleItemWidget(title: "Address", value: "${userEntity.address} "),
                sizeVer(10),
                Divider(color: Colors.grey,),
                sizeVer(10),
                InkWell(
                  onTap: () {
                    Navigator.pushNamed(context, PageConst.feedBackPage, arguments: userEntity);
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text("Driver Feedbacks", style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),),
                      sizeHor(8),
                      Icon(Icons.arrow_forward_ios, size: 25),
                    ],
                  ),
                ),
                sizeVer(10),
              ],
            ),
          ),
        ),
      ),
    );
  }


}
