
import 'package:flutter/material.dart';

import '../../../widgets/common.dart';


class ProfileSingleItemWidget extends StatelessWidget {
  final String? title;
  final String? value;
  final TextEditingController? controller;
  final bool? isEditable;
  const ProfileSingleItemWidget({Key? key, this.title, this.value, this.controller, this.isEditable}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text("$title :", style: TextStyle(fontSize: 18),),
        sizeHor(30),
        isEditable == true ?Expanded(
          child: TextFormField(
            controller: controller,
            decoration: InputDecoration(
              hintText: title
            ),
          ),
        ) : Expanded(child: Text("$value", style: TextStyle(fontSize: 18),)),
      ],
    );
  }
}
