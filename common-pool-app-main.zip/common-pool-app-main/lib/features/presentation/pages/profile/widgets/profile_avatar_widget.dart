

import 'dart:io';

import 'package:common_pool_app/features/presentation/widgets/profile_widget.dart';
import 'package:common_pool_app/theme/colors.dart';
import 'package:flutter/material.dart';

class ProfileAvatarWidget extends StatelessWidget {
  final File? image;
  final String? imageUrl;
  final bool? isEditable;
  final VoidCallback? onEditListener;
  const ProfileAvatarWidget({Key? key, this.image, this.isEditable, this.onEditListener, this.imageUrl}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return isEditable == true ? Stack(
      children: [
        ClipRRect(borderRadius: BorderRadius.circular(25),child: Container(width: 50, height: 50,child: profileWidget(image: image, imageUrl: imageUrl))),
        Positioned(
          top: 30,
          right: 0,
          child: Container(width: 20, height: 20, decoration: BoxDecoration(
            color: primaryColor,
            shape: BoxShape.circle
          ),child: InkWell(onTap: onEditListener,child: Icon(Icons.edit, size: 15,))),
        )
      ],
    ) : ClipRRect(borderRadius: BorderRadius.circular(25),child: Container(width: 50, height: 50,child: profileWidget(image: image, imageUrl: imageUrl)));
  }
}
