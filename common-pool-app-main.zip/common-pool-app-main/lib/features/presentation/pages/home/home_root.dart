
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_icons/flutter_icons.dart';

import '../../../../theme/colors.dart';
import '../../cubit/single_user/single_user_cubit.dart';
import '../profile/root/profile_page.dart';
import '../rider/root/riders_page.dart';
import 'home_page/home_page.dart';

class HomeRoot extends StatefulWidget {
  final UserEntity currentUser;
  const HomeRoot({Key? key, required this.currentUser}) : super(key: key);

  @override
  State<HomeRoot> createState() => _HomeRootState();
}

class _HomeRootState extends State<HomeRoot> {

  int index = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: Container(
          height: 60,
          decoration: BoxDecoration(
            border: Border(top: BorderSide(color: Colors.black, width: 1)),
          ),
          child: BottomNavigationBar(
            backgroundColor: Colors.white,
            selectedItemColor: primaryColor,
            currentIndex: index,
            onTap: (i) {
              setState(() {
                index = i;
              });
            },
            items: [
              // Icon(Icons.home, color: Colors.white),
              // Icon(AntDesign.form, color: Colors.white),
              // Icon(FontAwesome.user, color: Colors.white),
              BottomNavigationBarItem(icon: Icon(Icons.home), label: "Home"),
              BottomNavigationBarItem(icon: Icon(Ionicons.md_car), label: "Rides"),
              BottomNavigationBarItem(icon: Icon(FontAwesome.user), label: "Profile")

            ],
          ),
        ),
        body: BlocBuilder<SingleUserCubit,SingleUserState>(
          builder: (context,singleUserState){

            if (singleUserState is SingleUserLoaded){
              final currentUser =singleUserState.user;
              return _pageSwitch(currentUser);
            }

            return centerProgressBarIndicator();
          },
        )
    );
  }

  Widget _pageSwitch(UserEntity currentUser){
    switch(index){
      case 0:
        return HomePage(userEntity: currentUser);
      case 1:
        return RidersPage(userEntity: currentUser,);
      case 2:
        return ProfilePage(userEntity: currentUser);
      default:
        return Container();

    }
  }
}
