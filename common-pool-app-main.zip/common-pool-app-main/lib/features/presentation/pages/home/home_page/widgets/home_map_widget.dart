import 'dart:async';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_current_uid_usecase.dart';
import 'package:common_pool_app/features/presentation/cubit/driver/driver_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/user/user_cubit.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'dart:ui' as ui;

import '../../../../../../../consts.dart';
import 'package:common_pool_app/injection_container.dart' as di;

import '../../../rider/sub_pages/book_ride_page.dart';

class HomeMapWidget extends StatefulWidget {
  final Coordinates? coordinates;
  final UserEntity currentUser;
  final Function(Coordinates coordinates, String address, String adminArea) onLocationListener;

  const HomeMapWidget({Key? key, required this.currentUser, this.coordinates, required this.onLocationListener}) : super(key: key);

  @override
  _HomeMapWidgetState createState() => _HomeMapWidgetState();
}

class _HomeMapWidgetState extends State<HomeMapWidget> {
  Coordinates? _driverLocationLocationLatLong;
  Coordinates? _passengerLocationLocationLatLong;

  Completer<GoogleMapController> _controller = Completer();
  List<Marker> markers = [];
  String? _selectedLocation;
  bool _isMapTypeTerrain = true;
  bool updateMarkersOnce = false;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  String _currentUid = "";

  @override
  void initState() {
    _getCurrentLocation();
    // _getStreamLocation();
    _getStreamLocation();
    di.sl<GetCurrentUidUseCase>().call().then((value) {
      _currentUid = value;
    });
    super.initState();
  }

  _getCurrentLocation() async {
    Location().getLocation().then((locationData) async {
      print(locationData.latitude);
      print(locationData.longitude);

      _passengerLocationLocationLatLong = Coordinates(locationData.latitude, locationData.longitude);
      final latLong = widget.coordinates == null ? LatLng(locationData.latitude!, locationData.longitude!) : LatLng(widget.coordinates!.latitude!, widget.coordinates!.longitude!);
      GoogleMapController googleMapController = await _controller.future;
      googleMapController.animateCamera(CameraUpdate.newCameraPosition(CameraPosition(target: latLong, zoom: 14)));
    });
  }

  _getStreamLocation() async {
    ///if (accountType == driver)
    Location().onLocationChanged.listen((locationData) async {
      Future.delayed(Duration(seconds: 30), () {
        if (widget.currentUser.accountType == AccountConst.driver){
          print("driverLocUpdatedHomeMap");
          BlocProvider.of<UserCubit>(context).getUpdateUser(
            UserEntity(
              uid: widget.currentUser.uid,
              locationPoint: GeoPoint(locationData.latitude!, locationData.longitude!)
            )
          );
        }
      });

    });
  }

  _setMarker({required LatLng locationData, UserEntity? userEntity}) async {
    final Uint8List markerIcon = await getBytesFromAsset("assets/driver_marker.png", 80);

    final newAddress = await _coordinatesToAddress(Coordinates(locationData.latitude, locationData.longitude));
    final MarkerId markerId = MarkerId(
      UniqueKey().toString(),
    );
    Marker marker = Marker(
      markerId: markerId,

      infoWindow: InfoWindow(
          // title: "${userEntity!.uid != _currentUid? "Book Driver" : "Me" }",
          title: "Book Driver",
          onTap: () {
            _showBookingDialog(context, userEntity!);
            // if (userEntity.uid != _currentUid) {
            //   return _showBookingDialog(context);
            // } else {
            //   return null;
            // }
          }),
      position: LatLng(locationData.latitude, locationData.longitude),
      //icon: BitmapDescriptor.defaultMarker,
      icon: BitmapDescriptor.fromBytes(markerIcon),
    );
    if (mounted) {
      setState(() {
        _selectedLocation = newAddress;
        markers.add(marker);
      });
    }
  }

  _setCurrentLocationMarker({required LatLng locationData, UserEntity? userEntity}) async {
    final Uint8List markerIcon = await getBytesFromAsset("assets/driver_marker.png", 40);

    final newAddress = await _coordinatesToAddress(Coordinates(locationData.latitude, locationData.longitude));
    final MarkerId markerId = MarkerId(
      UniqueKey().toString(),
    );
    Marker marker = Marker(
      markerId: markerId,

      infoWindow: InfoWindow(
          // title: "${userEntity!.uid != _currentUid? "Book Driver" : "Me" }",
          title: "Book Driver",
          onTap: () {
            _showBookingDialog(context, userEntity!);
            // if (userEntity.uid != _currentUid) {
            //   return _showBookingDialog(context);
            // } else {
            //   return null;
            // }
          }),
      position: LatLng(locationData.latitude, locationData.longitude),
      icon: BitmapDescriptor.defaultMarker,
      // icon: BitmapDescriptor.fromBytes(markerIcon),
    );
    setState(() {
      markers.clear();
      _selectedLocation = newAddress;
      markers.add(marker);
    });
  }

  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address = await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;
    // print("address $address");
    // print(newAddress);
    // print("subLocality ${newAddress.subLocality} \n");
    // print("addressLine ${newAddress.addressLine} \n");
    // print("Country ${newAddress.countryName}");
    // print("subAdminArea  ${newAddress.adminArea}");
    // print("featureName  ${newAddress.featureName}");
    // print("locality  ${newAddress.locality}");
    widget.onLocationListener(coordinates, newAddress.addressLine, newAddress.locality);
    return "${newAddress.locality}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: BlocBuilder<DriverCubit, DriverState>(
        builder: (context, driverState) {
          if (driverState is DriverLoaded) {
            _updateGoogleMapMarkers(driverState.drivers);
            return Stack(
              children: [
                Container(
                  child: GoogleMap(
                    mapType: _isMapTypeTerrain == true ? MapType.terrain : MapType.hybrid,
                    zoomControlsEnabled: true,
                    zoomGesturesEnabled: true,
                    onTap: (locationData) {
                      print("selected Location ${locationData.longitude}");
                      //_setCurrentLocationMarker(locationData: LatLng(locationData.latitude, locationData.longitude));
                    },
                    onCameraMove: (newPosition) {
                      print("new position ${newPosition.target.latitude}");
                    },
                    compassEnabled: true,
                    trafficEnabled: true,
                    mapToolbarEnabled: true,
                    markers: markers.toSet(),
                    indoorViewEnabled: true,
                    myLocationEnabled: true,
                    myLocationButtonEnabled: true,
                    initialCameraPosition: _kGooglePlex,
                    onMapCreated: (GoogleMapController controller) {
                      _controller.complete(controller);
                    },
                  ),
                ),
                Positioned(
                    top: 10,
                    left: 10,
                    child: GestureDetector(
                      onTap: () {
                        setState(() {
                          _isMapTypeTerrain = _isMapTypeTerrain == true ? false : true;
                        });
                      },
                      child: Container(
                        height: 50,
                        width: 50,
                        decoration: BoxDecoration(color: Colors.white, shape: BoxShape.circle, border: Border.all(color: Colors.black, width: 1.2)),
                        child: Icon(
                          Icons.map,
                          color: _isMapTypeTerrain == true ? Colors.green : Colors.black,
                        ),
                      ),
                    )),
              ],
            );
          }

          return centerProgressBarIndicator();
        },
      ),
    );
  }

  _showBookingDialog(BuildContext context, UserEntity driver) {
    return showDialog(
        context: context,
        builder: (context) {
          return Dialog(
            alignment: Alignment.center,
            child: Container(
              width: 200,
              height: 150,
              padding: EdgeInsets.symmetric(horizontal: 10, vertical: 10),
              child: Column(
                children: [
                  Text(
                    "Book ${driver.username} Driver?",
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                  ),
                  sizeVer(10),
                  ButtonContainerWidget(
                    text: "Book Now",
                    isCenter: true,
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => BookRidePage(driverEntity: driver, passengerLocation: _passengerLocationLocationLatLong!)));
                    },
                  ),
                  sizeVer(10),
                  Divider(
                    color: Colors.black,
                  ),
                  driver.totalRating == 0
                      ? Text(
                          "Driver got no feedbacks yet",
                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                        )
                      : InkWell(
                    onTap: () {
                      Navigator.pushNamed(context, PageConst.feedBackPage, arguments:driver);
                    },
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.star, color: Colors.amber,),
                            sizeHor(3),
                            Text("(${driver.totalRating}) feedbacks", style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),)
                          ],
                        )
                      ),
                  sizeVer(10),

                  /// Logic Deprecated
                  // InkWell(
                  //   onTap: () {
                  //     Navigator.pushNamed(context, PageConst.viewProfilePage, arguments: widget.currentUser);
                  //   },
                  //   child: Row(
                  //     mainAxisAlignment: MainAxisAlignment.center,
                  //     children: [
                  //       Text("Checkout", style: TextStyle(fontSize: 16),),
                  //       sizeHor(8),
                  //       Icon(Icons.arrow_forward_ios, size: 20,),
                  //     ],
                  //   ),
                  // )
                ],
              ),
            ),
          );
        });
  }

  void _updateGoogleMapMarkers(List<UserEntity> drivers) {
    WidgetsBinding.instance!.addPostFrameCallback((timeStamp) {
      if (updateMarkersOnce == false) {
        drivers.forEach((element) {
          if (element.locationPoint != null) {
            if (element.uid != widget.currentUser.uid) {
              _setMarker(locationData: LatLng(element.locationPoint!.latitude, element.locationPoint!.longitude), userEntity: element);
            }
          }
        });
      }

      if (mounted)
        setState(() {
          updateMarkersOnce = true;
        });
    });
  }
}
