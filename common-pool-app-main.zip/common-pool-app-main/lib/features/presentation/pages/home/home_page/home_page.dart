
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/pages/home/home_page/widgets/home_map_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/button_container_widget.dart';
import 'package:common_pool_app/features/presentation/widgets/common.dart';
import 'package:common_pool_app/features/presentation/widgets/main_text_widget.dart';
import 'package:flutter/material.dart';
import 'package:geocoder/model.dart';


class HomePage extends StatelessWidget {
  final UserEntity userEntity;
  const HomePage({Key? key, required this.userEntity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

           HomeMapWidget(currentUser: userEntity,onLocationListener: (Coordinates coordinates, String address,String adminArea) {

          }),
        ],
      ),
    );
  }
}
