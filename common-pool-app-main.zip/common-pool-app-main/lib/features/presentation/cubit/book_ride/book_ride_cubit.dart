import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_all_book_rides_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_delete_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_post_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_update_book_ride_usecase.dart';
import 'package:equatable/equatable.dart';

part 'book_ride_state.dart';

class BookRideCubit extends Cubit<BookRideState> {
  final GetAllBookRidesUseCase getAllBookRidesUseCase;
  final GetPostBookRidesUseCase getPostBookRidesUseCase;
  final GetUpdateBookRidesUseCase getUpdateBookRidesUseCase;
  final GetDeleteBookRidesUseCase getDeleteBookRidesUseCase;
  BookRideCubit({required this.getAllBookRidesUseCase, required this.getPostBookRidesUseCase, required this.getUpdateBookRidesUseCase, required this.getDeleteBookRidesUseCase}) : super(BookRideInitial());

  Future<void> getPostBookRide({required BookRideEntity bookRideEntity})async{
    try{
      await getPostBookRidesUseCase.call(bookRideEntity);
    }on SocketException catch(_){
      emit(BookRideFailure());
    }catch(_){
      emit(BookRideFailure());
    }
  }

  Future<void> getDeleteBookRide({required BookRideEntity bookRideEntity})async{
    try{
      await getDeleteBookRidesUseCase.call(bookRideEntity);
    }on SocketException catch(_){
      emit(BookRideFailure());
    }catch(_){
      emit(BookRideFailure());
    }
  }
  Future<void> getUpdateBookRide({required BookRideEntity bookRideEntity})async{
    try{
      await getUpdateBookRidesUseCase.call(bookRideEntity);
    }on SocketException catch(_){
      emit(BookRideFailure());
    }catch(_){
      emit(BookRideFailure());
    }
  }
  Future<void> getAllBookRides()async{
    emit(BookRideLoading());
    final streamResponse = getAllBookRidesUseCase.call();
    streamResponse.listen((bookRide) {
      print("BookedRideLength :${bookRide.length}");
      emit(BookRideLoaded(bookRideData: bookRide));
    });
  }

}
