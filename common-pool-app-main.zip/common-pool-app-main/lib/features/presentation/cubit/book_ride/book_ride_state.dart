part of 'book_ride_cubit.dart';

abstract class BookRideState extends Equatable {
  const BookRideState();
}

class BookRideInitial extends BookRideState {
  @override
  List<Object> get props => [];
}
class BookRideLoaded extends BookRideState {
  final List<BookRideEntity> bookRideData;

  BookRideLoaded({required this.bookRideData});
  @override
  List<Object> get props => [bookRideData];
}
class BookRideFailure extends BookRideState {
  @override
  List<Object> get props => [];
}
class BookRideLoading extends BookRideState {
  @override
  List<Object> get props => [];
}
