part of 'single_book_ride_cubit.dart';

abstract class SingleBookRideState extends Equatable {
  const SingleBookRideState();
}

class SingleBookRideInitial extends SingleBookRideState {
  @override
  List<Object> get props => [];
}

class SingleBookRideLoading extends SingleBookRideState {
  @override
  List<Object> get props => [];
}

class SingleBookRideLoaded extends SingleBookRideState {
  final BookRideEntity bookRide;

  SingleBookRideLoaded({required this.bookRide});
  @override
  List<Object> get props => [bookRide];
}

class SingleBookRideFailure extends SingleBookRideState {
  @override
  List<Object> get props => [];
}


