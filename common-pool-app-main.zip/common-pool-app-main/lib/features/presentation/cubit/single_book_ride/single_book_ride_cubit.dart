import 'package:bloc/bloc.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_single_book_ride_usecase.dart';
import 'package:equatable/equatable.dart';

part 'single_book_ride_state.dart';

class SingleBookRideCubit extends Cubit<SingleBookRideState> {
  final GetSingleBookRideUseCase getSingleBookRideUseCase;
  SingleBookRideCubit({required this.getSingleBookRideUseCase}) : super(SingleBookRideInitial());

  Future<void> getSingleBookRIde({required String bookRideId}) async {
    emit(SingleBookRideLoading());
    final streamResponse = getSingleBookRideUseCase.call(bookRideId);
    streamResponse.listen((bookRide) {
      print(bookRide.length);
      emit(SingleBookRideLoaded(bookRide: bookRide.first));
    });
  }
}
