import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_all_drivers_usecase.dart';
import 'package:equatable/equatable.dart';

import '../../../domain/entities/user_entity.dart';
import '../../../domain/use_cases/user_usecases/get_all_users_usecase.dart';
import '../../../domain/use_cases/user_usecases/get_update_user.dart';

part 'user_state.dart';

class UserCubit extends Cubit<UserState> {
  final GetAllUsersUseCase getAllUsersUseCase;
  final GetUpdateUserUseCase getUpdateUserUseCase;

  UserCubit({required this.getAllUsersUseCase, required this.getUpdateUserUseCase}) : super(UserInitial());


  Future<void> getUsers() async {
    emit(UserLoading());
    final streamResponse = getAllUsersUseCase.call();
    streamResponse.listen((users) {
      print(users.length);
      emit(UserLoaded(users: users));
    });
  }




  Future<void> getUpdateUser(UserEntity user) async {
    try {
      await getUpdateUserUseCase.call(user);
    } on SocketException catch (_) {
      emit(UserFailure());
    } catch (_) {
      emit(UserFailure());
    }
  }
}
