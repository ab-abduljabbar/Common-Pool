import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../domain/entities/user_entity.dart';
import '../../../domain/use_cases/user_usecases/get_single_user_usecase.dart';

part 'single_user_state.dart';

class SingleUserCubit extends Cubit<SingleUserState> {
  final GetSingleUserUseCase getSingleUserUseCase;
  SingleUserCubit({required this.getSingleUserUseCase}) : super(SingleUserInitial());


  Future<void> getSingleUser({required String uid}) async {
    emit(SingleUserLoading());
    final streamResponse = getSingleUserUseCase.call(uid);
    streamResponse.listen((users) {
      print(users.length);
      emit(SingleUserLoaded(user: users.first));
    });
  }

}
