import 'dart:io';
import 'package:bloc/bloc.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/forget_password_usecase.dart';
import 'package:equatable/equatable.dart';
import '../../../../domain/entities/user_entity.dart';
import '../../../../domain/use_cases/user_usecases/get_create_current_user_usecase.dart';
import '../../../../domain/use_cases/user_usecases/is_check_email_verification_usecase.dart';
import '../../../../domain/use_cases/user_usecases/login_user_usecase.dart';
import '../../../../domain/use_cases/user_usecases/register_user_usecase.dart';
part 'credential_state.dart';

class CredentialCubit extends Cubit<CredentialState> {
  final LoginUserUseCase loginUserUseCase;
  final RegisterUserUseCase registerUserUseCase;
  final GetCreateCurrentUserUseCase getCreateCurrentUserUseCase;
  final IsCheckEmailVerificationUseCase isCheckEmailVerificationUseCase;
  final ForgetPasswordUseCase forgetPasswordUseCase;

  CredentialCubit({required this.forgetPasswordUseCase, required this.isCheckEmailVerificationUseCase,required this.getCreateCurrentUserUseCase, required this.loginUserUseCase, required this.registerUserUseCase}) : super(CredentialInitial());


  Future<void> signInSubmit({
    required String email,
    required String password,
  }) async {
    emit(CredentialLoading());
    try {
      await loginUserUseCase.call(UserEntity(email: email, password: password));
      emit(CredentialSuccess());
    } on SocketException catch (_) {
      emit(CredentialFailure());
    } catch (_) {
      emit(CredentialFailure());
    }
  }

  Future<void> signUpSubmit({required UserEntity user}) async {
    emit(CredentialLoading());
    try {
      await registerUserUseCase
          .call(user);
      emit(CredentialSuccess());
    } on SocketException catch (_) {
      emit(CredentialFailure());
    } catch (_) {
      emit(CredentialFailure());
    }
  }

  Future<void> forgotPassword({required String email})async{
    try{
      await forgetPasswordUseCase.call(email);
    }on SocketException catch(_){
      emit(CredentialFailure());
    }catch(_){
      emit(CredentialFailure());
    }
  }



// await getCreateCurrentUserUseCase.call(userEntity);
  // emit(CredentialSuccess());

  // Future<void> checkEmailVerification() async {
  //   emit(CredentialLoading());
  //   try {
  //     final isVerifiedEmail = await isCheckEmailVerificationUseCase.call();
  //     if (isVerifiedEmail == true){
  //       emit(CredentialSuccess());
  //     }else{
  //
  //     }
  //   } on SocketException catch (_) {
  //     // emit(CredentialFailure());
  //   } catch (_) {
  //     // emit(CredentialFailure());
  //   }
  // }
  //
  // Future<void> backToLogin()async{
  //   emit(CredentialFailureEmailIssue());
  // }
}

