import 'dart:io';

import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';

import '../../../domain/entities/feedback_entity.dart';
import '../../../domain/use_cases/feedback/add_feedback_usecase.dart';
import '../../../domain/use_cases/feedback/delete_feedback_usecase.dart';
import '../../../domain/use_cases/feedback/get_all_feedback_usecase.dart';

part 'feedback_state.dart';

class FeedbackCubit extends Cubit<FeedbackState> {
  final AddFeedbackUseCase addFeedbackUseCase;
  final DeleteFeedbackUseCase deleteFeedbackUseCase;
  final GetAllFeedbackUseCase getAllFeedbackUseCase;

  FeedbackCubit({
    required this.addFeedbackUseCase,
    required this.deleteFeedbackUseCase,
    required this.getAllFeedbackUseCase,
  }) : super(FeedbackInitial());

  Future<void> getFeedbacks({required FeedbackEntity feedbackEntity})async{
    try{
      getAllFeedbackUseCase.call(feedbackEntity).listen((event) {
        emit(FeedbackLoaded(feedbacks: event));
      });
    }on SocketException catch(_){
      emit(FeedbackFailure());
    }catch(_){
      emit(FeedbackFailure());
    }
  }

  Future<void> addFeedback({required FeedbackEntity feedbackEntity})async{
    try{

      addFeedbackUseCase.call(feedbackEntity);

    }on SocketException catch(_){
      emit(FeedbackFailure());
    }catch(_){
      emit(FeedbackFailure());
    }
  }

}
