part of 'feedback_cubit.dart';

abstract class FeedbackState extends Equatable {
  const FeedbackState();
}

class FeedbackInitial extends FeedbackState {
  @override
  List<Object> get props => [];
}

class FeedbackLoaded extends FeedbackState {
  final List<FeedbackEntity> feedbacks;

  FeedbackLoaded({required this.feedbacks});
  @override
  List<Object> get props => [feedbacks];
}
class FeedbackFailure extends FeedbackState {
  @override
  List<Object> get props => [];
}

class FeedbackLoading extends FeedbackState {
  @override
  List<Object> get props => [];
}