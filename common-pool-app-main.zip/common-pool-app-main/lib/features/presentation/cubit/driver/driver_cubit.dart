import 'package:bloc/bloc.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:equatable/equatable.dart';

import '../../../domain/use_cases/user_usecases/get_all_drivers_usecase.dart';

part 'driver_state.dart';

class DriverCubit extends Cubit<DriverState> {
  final GetAllDriversUseCase getAllDriversUseCase;
  DriverCubit({required this.getAllDriversUseCase}) : super(DriverInitial());

  Future<void> getDrivers() async {
    emit(DriverLoading());
    try{
      final streamResponse = getAllDriversUseCase.call();
      streamResponse.listen((drivers) {
        print(drivers.length);
        emit(DriverLoaded(drivers:drivers));
      });
    }catch(_){
      emit(DriverFailure());
    }
  }
}
