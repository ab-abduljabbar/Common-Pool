part of 'driver_cubit.dart';

abstract class DriverState extends Equatable {
  const DriverState();
}

class DriverInitial extends DriverState {
  @override
  List<Object> get props => [];
}

class DriverFailure extends DriverState {
  @override
  List<Object> get props => [];
}

class DriverLoaded extends DriverState {
  final List<UserEntity> drivers;

  DriverLoaded({required this.drivers});

  @override
  List<Object> get props => [drivers];
}

class DriverLoading extends DriverState {
  @override
  List<Object> get props => [];
}
