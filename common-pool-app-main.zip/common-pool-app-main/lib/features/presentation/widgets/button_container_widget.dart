import 'package:flutter/material.dart';

import '../../../theme/colors.dart';
import 'common.dart';

class ButtonContainerWidget extends StatelessWidget {
  final VoidCallback? onTap;
  final double? width;
  final double? height;
  final bool? isOutline;
  final double? radius;
  final String text;
  final bool? isIconPresent;
  final IconData? icon;
  final double? iconSize;
  final bool? isCenter;
  final List<BoxShadow>? boxShadow;
  final FontWeight? fontWeight;
  final bool? manualColor;
  final Color? color;
  final Color? textColor;
  const ButtonContainerWidget({Key? key, this.width = 200, this.height = 40, required this.text, this.isOutline, this.radius=20, this.isIconPresent=false, this.icon, this.iconSize, this.isCenter, this.onTap, this.boxShadow, this.fontWeight, this.manualColor, this.color=primaryColor, this.textColor= Colors.white}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return isCenter == true ? Center(
      child: InkWell(
        onTap: onTap,
        child: Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
            color: isOutline == true? Colors.white : color,
            border: isOutline==true? Border.all(width: 1, color: Colors.black) : Border(),
            borderRadius: BorderRadius.circular(radius!),
            boxShadow: boxShadow
          ),
          child: Center(
            child: isIconPresent == false? Text(
              "$text",
              style: TextStyle(color: isOutline==true?  primaryColor : Colors.white, fontSize: 18),
            ) : Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: iconSize, color: color,),
                sizeHor(8),
                Text(
                  "$text",
                  style: TextStyle(color: manualColor == true ? textColor : isOutline==true?  primaryColor : Colors.white, fontSize: 18),
                )
              ],
            ),
          ),
        ),
      ),
    ) : InkWell(
      onTap: onTap,
      child: Container(
        width: width,
        height: height,
        decoration: BoxDecoration(
          color: isOutline == true? Colors.white : color,
          border: isOutline==true? Border.all(width: 1, color: Colors.black) : Border(),
          borderRadius: BorderRadius.circular(radius!),
            boxShadow: boxShadow
        ),
        child: Center(
          child: isIconPresent == false? Text(
            "$text",
            style: TextStyle(color: manualColor == true ? textColor : isOutline==true?  primaryColor : Colors.white, fontSize: 18, fontWeight: fontWeight),
          ) : Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: iconSize, color: color,),
              sizeHor(8),
              Text(
                "$text",
                style: TextStyle(color: manualColor == true ? textColor :    isOutline==true?  primaryColor : Colors.white, fontSize: 18),
              )
            ],
          ),
        ),
      ),
    );
  }
}
