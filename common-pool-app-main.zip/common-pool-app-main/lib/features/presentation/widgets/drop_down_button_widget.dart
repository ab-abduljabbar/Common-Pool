// import 'package:flutter/material.dart';
//
// import '../../../theme/colors.dart';
//
// class DropDownButtonWidget extends StatefulWidget {
//   final List<String> items;
//
//   const DropDownButtonWidget({Key? key, required this.items}) : super(key: key);
//   @override
//   _DropDownButtonWidgetState createState() => _DropDownButtonWidgetState();
// }
//
// class _DropDownButtonWidgetState extends State<DropDownButtonWidget> {
//
//   String dropDownDefaultValue = "Select Area";
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       padding: EdgeInsets.symmetric(horizontal: 8.0),
//       decoration: BoxDecoration(
//           color: primaryColor.withOpacity(.4),
//           border: Border.all(width: 1)
//       ),
//       child: Row(
//         mainAxisAlignment: MainAxisAlignment.spaceBetween,
//         children: [
//           Text("$dropDownDefaultValue", style: TextStyle(fontSize: 16),),
//           DropdownButton<String>(
//             items: widget.items.map((String value) {
//               return DropdownMenuItem<String>(
//                 value: value,
//                 child: Text(value),
//               );
//             }).toList(),
//             icon: Icon(
//               Icons.arrow_drop_down_sharp,
//             ),
//             onChanged: (value) {
//               setState(() {
//                 dropDownDefaultValue = value!;
//               });
//             },
//           ),
//         ],
//       ),
//     );
//   }
// }


import 'package:flutter/material.dart';


class DropDownButtonWidget extends StatefulWidget {
  final List<String> items;
  final TextEditingController? controller;
  final String? hint;
  final bool? isGender;
  final bool? isProfileDropDown;

  const DropDownButtonWidget({Key? key, required this.items, this.controller, this.hint, this.isGender, this.isProfileDropDown=false}) : super(key: key);
  @override
  _DropDownButtonWidgetState createState() => _DropDownButtonWidgetState();
}

class _DropDownButtonWidgetState extends State<DropDownButtonWidget> {


  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      height: 50,
      padding:widget.isProfileDropDown == true ? EdgeInsets.zero : EdgeInsets.symmetric(horizontal: 15),
      decoration: BoxDecoration(
          color: Colors.white,
        border: Border.all(width: 1)
      ),
      child: Row(
        children: [
          Expanded(
            child: TextFormField(
              controller: widget.controller,
              decoration: InputDecoration(
                border: InputBorder.none,
                hintText: widget.hint,
                hintStyle: TextStyle(fontSize: 14),
                contentPadding: EdgeInsets.only(top: 14),
                suffixIcon: DropdownButton<String>(
                  items: widget.items.map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  icon: Icon(
                    Icons.arrow_drop_down,
                    color: Colors.black,
                    size: 20,
                  ),

                  onChanged: (value) {
                    setState(() {
                      widget.controller!.text = value!;
                    });
                  },
                ),
              ),
            ),
          ),
          // Expanded(
          //   child:
          // ),
        ],
      ),
    );
  }
}