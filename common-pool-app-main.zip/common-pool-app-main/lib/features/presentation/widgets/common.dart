



import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';


String getVideoId(String url){
  return url.split("v=").last;
}
String getVideoThumb({required String id}){
  return "https://img.youtube.com/vi/$id/default.jpg";
}


Widget sizeVer(double height) {
  return SizedBox(height: height,);
}

Widget sizeHor(double width) {
  return SizedBox(width: width,);
}





Widget centerProgressBarIndicator(){
  return Center(
    child: CircularProgressIndicator(),
  );
}
void snackBar({required String msg, required GlobalKey<ScaffoldState> scaffoldState}) {
  scaffoldState.currentState!.showSnackBar(
    SnackBar(
      content: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(msg,style: TextStyle(fontWeight: FontWeight.w500),),
          CircularProgressIndicator(),
        ],
      ),
    ),
  );
}


void push({required BuildContext context, required Widget widget}) {
  Navigator.push(context, MaterialPageRoute(builder: (_) => widget));
}

void toast(String message) {
  Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.BOTTOM,
      timeInSecForIosWeb: 1,
      backgroundColor: Colors.red,
      textColor: Colors.white,
      fontSize: 16.0);
}


//TODO:common button [Today,this week,this month]
Widget verticalDivider(){
  return Container(
    margin: EdgeInsets.symmetric(horizontal: 4),
    height:18,
    width: 1.0,
    decoration: BoxDecoration(
        color: Colors.black.withOpacity(.4)
    ),
  );
}