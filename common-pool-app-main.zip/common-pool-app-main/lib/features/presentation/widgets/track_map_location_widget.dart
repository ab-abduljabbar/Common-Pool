import 'dart:async';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:geocoder/geocoder.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';
import 'dart:ui' as ui;
import 'package:common_pool_app/injection_container.dart' as di;
import 'package:maps_launcher/maps_launcher.dart' as launch;
import 'package:maps_launcher/maps_launcher.dart';

import '../../domain/use_cases/user_usecases/get_current_uid_usecase.dart';


class TrackMapLocationWidget extends StatefulWidget {
  final BookRideEntity bookRideEntity;
  final UserEntity currentUser;
  const TrackMapLocationWidget({Key? key,required this.bookRideEntity,required this.currentUser})
      : super(key: key);

  @override
  _TrackMapLocationWidgetState createState() =>
      _TrackMapLocationWidgetState();
}

class _TrackMapLocationWidgetState extends State<TrackMapLocationWidget> {
  Completer<GoogleMapController> _controller = Completer();
  List<Marker> markers = [];
  String? _selectedLocation;
  bool _isMapTypeTerrain = true;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );
  String _currentUid = "";


  @override
  void initState() {
    _getStreamLocation();

    _setCoordsMarker();
    super.initState();
  }


  _getStreamLocation() async {
    ///if (accountType == driver)
    print("checkLocation");
    Location().onLocationChanged.listen((locationData) async {
      Future.delayed(Duration(seconds: 30), () {
          if (widget.currentUser.accountType == AccountConst.driver){
            BlocProvider.of<BookRideCubit>(context).getUpdateBookRide(bookRideEntity: BookRideEntity(
              driverLocation: GeoPoint(locationData.latitude!,locationData.longitude!),
              bookRideId: widget.bookRideEntity.bookRideId,
            ));
          }
      });

    });
  }

  _setCoordsMarker()async{


      final driverLocation=LatLng(widget.bookRideEntity.driverLocation!.latitude, widget.bookRideEntity.driverLocation!.longitude);
      final Uint8List driverMarkerIcon = await getBytesFromAsset("assets/driver_marker.png", 80);

      _setMarker(
          locationData:
          LatLng(driverLocation.latitude, driverLocation.longitude),markerIcon: driverMarkerIcon,title: "Driver Track");


      final Uint8List passengerMarkerIcon = await getBytesFromAsset("assets/passenger.png", 80);
      final passengerLocation=LatLng(widget.bookRideEntity.currentLocation!.latitude, widget.bookRideEntity.currentLocation!.longitude);


      _setMarker(locationData: LatLng(passengerLocation.latitude, passengerLocation.longitude),markerIcon: passengerMarkerIcon,title: "Passenger Location");


    //Distination Marker
    final latLong=LatLng(widget.bookRideEntity.destination!.latitude, widget.bookRideEntity.destination!.longitude);

    // googleMapController.animateCamera(CameraUpdate.newCameraPosition(
    //     CameraPosition(
    //         target: latLong,
    //         zoom: 14)));
    _setMarker(locationData: LatLng(latLong.latitude, latLong.longitude),title: "destination track");


      GoogleMapController googleMapController = await _controller.future;

      if (widget.currentUser.accountType == AccountConst.passenger){
        googleMapController.animateCamera(CameraUpdate.newCameraPosition(
            CameraPosition(
                target: driverLocation,
                zoom: 14)));
      }else{
        googleMapController.animateCamera(CameraUpdate.newCameraPosition(
            CameraPosition(
                target: passengerLocation,
                zoom: 14)));
      }

  }



  Future<Uint8List> getBytesFromAsset(String path, int width) async {
    ByteData data = await rootBundle.load(path);
    ui.Codec codec = await ui.instantiateImageCodec(data.buffer.asUint8List(), targetWidth: width);
    ui.FrameInfo fi = await codec.getNextFrame();
    return (await fi.image.toByteData(format: ui.ImageByteFormat.png))!.buffer.asUint8List();
  }


  _setMarker({required LatLng locationData, Uint8List? markerIcon,required String title}) async {
    final newAddress = await _coordinatesToAddress(
        Coordinates(locationData.latitude, locationData.longitude));
    final MarkerId markerId = MarkerId(
      UniqueKey().toString(),
    );
    Marker marker = Marker(
      markerId: markerId,
      infoWindow: InfoWindow(
        title: title,
        onTap: ()async {
          final driverLocation=LatLng(widget.bookRideEntity.driverLocation!.latitude, widget.bookRideEntity.driverLocation!.longitude);

          final  coordinates = Coordinates(driverLocation.longitude, driverLocation.latitude);
          
          // var addresses = await Geocoder.local
          //     .findAddressesFromQuery(
          // hospitalData[index].hospitalFullAddress);
          // var first = addresses.first;
          //
          MapsLauncher.launchCoordinates(coordinates.latitude, coordinates.longitude);
          // final availableMaps =
          //     await launch.MapsLauncher.installedMaps;
          // print(
          // "mapisAvb $availableMaps"); // [AvailableMap { mapName: Google Maps, mapType: google }, ...]
          // if (await launch.MapsLauncher.isMapAvailable(
          // MapType.hybrid)) {
          // await launch.MapsLauncher.showMarker(
          // mapType: MapType.hybrid,
          // coords: launch.MapsLauncher.launchCoordinates(first.coordinates.latitude,
          // first.coordinates.longitude),
          // title:
          // "${hospitalData[index].hospitalFullAddress}");
          // } else {
          // print("not avaiable");
          // }
        }
      ),
      position: LatLng(locationData.latitude, locationData.longitude),
      icon: markerIcon ==null?BitmapDescriptor.defaultMarker :BitmapDescriptor.fromBytes(markerIcon),
    );
    setState(() {
      _selectedLocation = newAddress;
      markers.add(marker);
    });
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;

    return "${newAddress.addressLine}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Tracker"),


      ),
      body: Stack(
        children: [
          Container(
            child: GoogleMap(
              mapType:
                  _isMapTypeTerrain == true ? MapType.terrain : MapType.hybrid,
              zoomControlsEnabled: true,
              zoomGesturesEnabled: true,
              onCameraMove: (newPosition) {
                print("new position ${newPosition.target.latitude}");
              },
              compassEnabled: true,
              trafficEnabled: true,
              mapToolbarEnabled: true,
              markers: markers.toSet(),
              indoorViewEnabled: true,
              myLocationEnabled: false,
              myLocationButtonEnabled: false,
              initialCameraPosition: _kGooglePlex,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
              },
            ),
          ),
          Positioned(
            top: 10,
              left: 10,
              child: GestureDetector(
            onTap: () {
              setState(() {
                _isMapTypeTerrain = _isMapTypeTerrain == true ? false : true;
              });
            },
            child: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 1.2)),
              child: Icon(Icons.map,color: _isMapTypeTerrain==true?Colors.green:Colors.black,),
            ),
          )),
        ],
      ),
    );
  }
}
