import 'package:flutter/material.dart';
import 'package:flutter_icons/flutter_icons.dart';

class LocationRowWidget extends StatelessWidget {
  final double? fontSize;

  const LocationRowWidget({Key? key, this.fontSize}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Location:",
            style: TextStyle(fontSize: fontSize),
          ),
          Icon(
            MaterialIcons.location_on,
            size: 30,
          ),
        ],
      ),
    );
  }
}
