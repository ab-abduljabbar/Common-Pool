
import 'package:flutter/material.dart';

import '../../../theme/colors.dart';
import 'common.dart';

class SquareContainerWidget extends StatelessWidget {
  final double? width;
  final double? height;
  final String? bottomTitle;
  final IconData? icon;
  final String? iconTitle;
  const SquareContainerWidget({Key? key, this.width=120, this.height=100, this.bottomTitle, this.icon, this.iconTitle}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Container(
          width: width,
          height: height,
          decoration: BoxDecoration(
              color: whiteColor,
              border: Border.all(width: 1, color: Colors.black)
          ),
          child: Padding(
            padding: const EdgeInsets.all(10.0),
            child: Column(
              children: [
                Icon(icon, size: 40,),
                sizeVer(5),
                Text(iconTitle!,  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
              ],
            ),
          ),
        ),
        sizeVer(10),
        Text(bottomTitle!, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),)
      ],
    );
  }
}
