import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

class MapLocationPickerWidget extends StatefulWidget {
  final Coordinates? coordinates;
  final Function(Coordinates coordinates, String address,String adminArea) onLocationListener;

  const MapLocationPickerWidget({Key? key, this.coordinates, required this.onLocationListener})
      : super(key: key);

  @override
  _MapLocationPickerWidgetState createState() =>
      _MapLocationPickerWidgetState();
}

class _MapLocationPickerWidgetState extends State<MapLocationPickerWidget> {
  Completer<GoogleMapController> _controller = Completer();
  List<Marker> markers = [];
  String? _selectedLocation;
  bool _isMapTypeTerrain = true;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  @override
  void initState() {
    _getCurrentLocation();
    if (widget.coordinates!=null){
      _setCoordsMarker();
    }
    super.initState();
  }

  _setCoordsMarker()async{
    final latLong=LatLng(widget.coordinates!.latitude!, widget.coordinates!.longitude!);

    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
            target: latLong,
            zoom: 14)));
    _setMarker(
        locationData:
        LatLng(latLong.latitude, latLong.longitude));
  }

  _getCurrentLocation() async {
    Location().getLocation().then((locationData) async {
      print(locationData.latitude);
      print(locationData.longitude);

      final latLong=widget.coordinates==null?LatLng(locationData.latitude!, locationData.longitude!):LatLng(widget.coordinates!.latitude!, widget.coordinates!.longitude!);
      GoogleMapController googleMapController = await _controller.future;
      googleMapController.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
              target: latLong,
              zoom: 14)));
      _setMarker(
          locationData:
              LatLng(locationData.latitude!, locationData.longitude!));
    });
  }

  _setMarker({required LatLng locationData}) async {
    final newAddress = await _coordinatesToAddress(
        Coordinates(locationData.latitude, locationData.longitude));
    final MarkerId markerId = MarkerId(
      UniqueKey().toString(),
    );
    Marker marker = Marker(
      markerId: markerId,
      infoWindow: InfoWindow(
        title: "$newAddress",
      ),
      position: LatLng(locationData.latitude, locationData.longitude),
      icon: BitmapDescriptor.defaultMarker,
      //icon: markerImage.isEmpty?BitmapDescriptor.defaultMarker :BitmapDescriptor.fromBytes(markerImage),
    );
    setState(() {
      markers.clear();
      _selectedLocation = newAddress;
      markers.add(marker);
    });
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;
    // print("address $address");
    // print(newAddress);
    // print("subLocality ${newAddress.subLocality} \n");
    // print("addressLine ${newAddress.addressLine} \n");
    // print("Country ${newAddress.countryName}");
    // print("subAdminArea  ${newAddress.adminArea}");
    // print("featureName  ${newAddress.featureName}");
    // print("locality  ${newAddress.locality}");
    widget.onLocationListener(coordinates, newAddress.addressLine,newAddress.locality);
    return "${newAddress.locality}";
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Text(_selectedLocation == null
                ? "Select Location"
                : "$_selectedLocation")),
        actions: [
          GestureDetector(
            onTap: (){
              Navigator.pop(context);
            },
            child: Container(
              margin: EdgeInsets.only(right: 15),
              child: Row(
                children: [
                  Text("Done"),
                  Icon(Icons.done),
                ],
              ),
            ),
          )
        ],
      ),
      body: Stack(
        children: [
          Container(
            child: GoogleMap(
              mapType:
                  _isMapTypeTerrain == true ? MapType.terrain : MapType.hybrid,
              zoomControlsEnabled: true,
              zoomGesturesEnabled: true,
              onTap: (locationData) {
                print("selected Location ${locationData.longitude}");
                _setMarker(
                    locationData:
                        LatLng(locationData.latitude, locationData.longitude));
              },
              onCameraMove: (newPosition) {
                print("new position ${newPosition.target.latitude}");
              },
              compassEnabled: true,
              trafficEnabled: true,
              mapToolbarEnabled: true,
              markers: markers.toSet(),
              indoorViewEnabled: true,
              myLocationEnabled: true,
              myLocationButtonEnabled: true,
              initialCameraPosition: _kGooglePlex,
              onMapCreated: (GoogleMapController controller) {
                _controller.complete(controller);
              },
            ),
          ),
          Positioned(
            top: 10,
              left: 10,
              child: GestureDetector(
            onTap: () {
              setState(() {
                _isMapTypeTerrain = _isMapTypeTerrain == true ? false : true;
              });
            },
            child: Container(
              height: 50,
              width: 50,
              decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  border: Border.all(color: Colors.black, width: 1.2)),
              child: Icon(Icons.map,color: _isMapTypeTerrain==true?Colors.green:Colors.black,),
            ),
          )),
        ],
      ),
    );
  }
}
