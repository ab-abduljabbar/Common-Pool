import 'dart:convert';
import 'dart:io';

import 'package:geocoder/geocoder.dart';
import 'package:image_picker/image_picker.dart';
import 'package:location/location.dart';

import '../common.dart';
final imageType = "data:image/jpeg;base64,";

Future<Address?> getCoordinatesOfQuery(String query) async {
 try{
   final coordinates = await Geocoder.local.findAddressesFromQuery(query);

   return coordinates.first;
 }catch(_){
   toast("Enter proper address query...");
   return null;
 }

}

Future getImage(
    {required Function(String? base64Image, File? imageFile)?
        onSaveBase64Listener}) async {
  await ImagePicker()
      .getImage(source: ImageSource.gallery, imageQuality: 50)
      .then((imageFile) async {
    if (imageFile != null) {
      List<int> imageBytes = File(imageFile.path).readAsBytesSync();
      String base64Image = base64Encode(imageBytes);
      final newBase64Image = imageType + base64Image;
      onSaveBase64Listener!(newBase64Image, File(imageFile.path));
    } else {
      print('No image selected.');
      onSaveBase64Listener!("", null);
    }
  });
}
