import 'package:flutter/material.dart';

import 'common.dart';

class OutlineContainerWidget extends StatelessWidget {
  final VoidCallback? onTap;
  final String? title;
  final String? image;
  final Widget? child;
  final bool isService;
  final double? width;
  final double? height;
  final double? margin;
  final Color? color;

  const OutlineContainerWidget({
    Key? key,
    this.color,
    this.onTap,
    this.title,
    this.image,
    this.child,
    required this.isService,
    this.width,
    this.height,
    this.margin,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Container(
            margin: EdgeInsets.all(5),
            padding: EdgeInsets.all(10),
            width: isService ? 110 : width,
            height: isService ? 110 : height,
            decoration: BoxDecoration(
              color: color,
              border: Border.all(width: 1, color: Colors.black),
              borderRadius: BorderRadius.circular(20),
            ),
            child: isService ? Image.asset("$image") : child,
          ),
        ),
        isService ? sizeVer(2) : Text(""),
        isService
            ? Text(
                "$title",
                style: TextStyle(fontSize: 18),
              )
            : Text("")
      ],
    );
  }
}
