import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geocoder/geocoder.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:location/location.dart';

class PropertyGoogleMapWidget extends StatefulWidget {
  final Coordinates? coordinates;

  const PropertyGoogleMapWidget({Key? key,required this.coordinates})
      : super(key: key);

  @override
  _PropertyGoogleMapWidgetState createState() =>
      _PropertyGoogleMapWidgetState();
}

class _PropertyGoogleMapWidgetState extends State<PropertyGoogleMapWidget> {
  Completer<GoogleMapController> _controller = Completer();
  List<Marker> markers = [];
  String? _selectedLocation;
  bool _isMapTypeTerrain = true;
  CameraPosition _kGooglePlex = CameraPosition(
    target: LatLng(37.42796133580664, -122.085749655962),
    zoom: 14.4746,
  );

  @override
  void initState() {
    //_getCurrentLocation();
    if (widget.coordinates!=null){
      _setMarker(
          locationData:
          LatLng(widget.coordinates!.latitude!, widget.coordinates!.longitude!));
    }
    super.initState();
  }

  _getCurrentLocation() async {
    Location().getLocation().then((locationData) async {
      print(locationData.latitude);
      print(locationData.longitude);
      print("checkCoordinates ${widget.coordinates}");
      final latLong=widget.coordinates==null?LatLng(locationData.latitude!, locationData.longitude!):LatLng(widget.coordinates!.latitude!, widget.coordinates!.longitude!);
      GoogleMapController googleMapController = await _controller.future;
      googleMapController.animateCamera(CameraUpdate.newCameraPosition(
          CameraPosition(
              target: latLong,
              zoom: 14)));
      _setMarker(
          locationData:
              LatLng(locationData.latitude!, locationData.longitude!));
    });
  }

  _setMarker({required LatLng locationData}) async {
    final newAddress = await _coordinatesToAddress(
        Coordinates(locationData.latitude, locationData.longitude));
    GoogleMapController googleMapController = await _controller.future;
    googleMapController.animateCamera(CameraUpdate.newCameraPosition(
        CameraPosition(
            target: LatLng(widget.coordinates!.latitude,widget.coordinates!.longitude),
            zoom: 14)));
    final MarkerId markerId = MarkerId(
      UniqueKey().toString(),
    );
    Marker marker = Marker(
      markerId: markerId,
      infoWindow: InfoWindow(
        title: "$newAddress",
      ),
      position: LatLng(locationData.latitude, locationData.longitude),
      icon: BitmapDescriptor.defaultMarker,
      //icon: markerImage.isEmpty?BitmapDescriptor.defaultMarker :BitmapDescriptor.fromBytes(markerImage),
    );
    setState(() {
      markers.clear();
      _selectedLocation = newAddress;
      markers.add(marker);
    });
  }

  Future<String> _coordinatesToAddress(Coordinates coordinates) async {
    final address =
        await Geocoder.local.findAddressesFromCoordinates(coordinates);
    final newAddress = address.first;
    // print("address $address");
    // print(newAddress);
    // print("subLocality ${newAddress.subLocality} \n");
    // print("addressLine ${newAddress.addressLine} \n");
    // print("Country ${newAddress.countryName}");
    // print("subAdminArea  ${newAddress.adminArea}");
    // print("featureName  ${newAddress.featureName}");
    // print("locality  ${newAddress.locality}");
    return "${newAddress.locality}";
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          child: GoogleMap(
            mapType:
            _isMapTypeTerrain == true ? MapType.terrain : MapType.hybrid,
            zoomControlsEnabled: true,
            zoomGesturesEnabled: true,
            onCameraMove: (newPosition) {
              print("new position ${newPosition.target.latitude}");
            },
            compassEnabled: true,
            trafficEnabled: true,
            mapToolbarEnabled: true,
            markers: markers.toSet(),
            indoorViewEnabled: true,
            myLocationEnabled: false,
            myLocationButtonEnabled: false,
            initialCameraPosition: _kGooglePlex,
            onMapCreated: (GoogleMapController controller) {
              _controller.complete(controller);
            },
          ),
        ),
        Positioned(
            top: 10,
            left: 10,
            child: GestureDetector(
              onTap: () {
                setState(() {
                  _isMapTypeTerrain = _isMapTypeTerrain == true ? false : true;
                });
              },
              child: Container(
                height: 50,
                width: 50,
                decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.black, width: 1.2)),
                child: Icon(Icons.map,color: _isMapTypeTerrain==true?Colors.green:Colors.black,),
              ),
            )),
      ],
    );
  }
}
