
import 'package:flutter/material.dart';

import '../../../theme/colors.dart';

class MainTextWidget extends StatelessWidget {
  final String? text;
  final Color? color;
  final double? size;
  final Color? dotColor;
  final MainAxisAlignment? mainAxisAlignment;
  const MainTextWidget({Key? key, this.text, this.color=Colors.black, this.size=66, this.dotColor=primaryColor, this.mainAxisAlignment=MainAxisAlignment.start}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      mainAxisAlignment: mainAxisAlignment!,
      children: [
        Text(text!, textAlign: TextAlign.center,style: TextStyle(fontSize: size, fontWeight: FontWeight.bold, color: color),),
        Text(".", style: TextStyle(fontSize: 66, fontWeight: FontWeight.bold, color: dotColor),)
      ],
    );
  }
}
