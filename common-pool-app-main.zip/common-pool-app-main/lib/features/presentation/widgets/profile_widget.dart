

import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';


Widget storyCompleteImageWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/default_profile.png',
        fit: BoxFit.cover,
      );
    else
      return Container(
        child: CachedNetworkImage(
          imageUrl: "$imageUrl",
          fit: BoxFit.cover,
          progressIndicatorBuilder: (context, url, downloadProgress) =>
              SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}

Widget storyResponseImageWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/default_profile.png',
        fit: BoxFit.cover,
      );
    else
      return Container(
        height: 30,
        width: double.infinity,
        child: CachedNetworkImage(
          imageUrl: "$imageUrl",
          fit: BoxFit.cover,
          progressIndicatorBuilder: (context, url, downloadProgress) =>
              SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}
Widget storyImageWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/default_profile.png',
        fit: BoxFit.cover,
      );
    else
      return Container(
        height: 150,
        child: CachedNetworkImage(
          imageUrl: "$imageUrl",
          fit: BoxFit.cover,
          progressIndicatorBuilder: (context, url, downloadProgress) =>
              SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}

Widget imageMessageWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/default_profile.png',
        fit: BoxFit.cover,
      );
    else
      return Container(
        height: 150,
        child: CachedNetworkImage(
          imageUrl: "$imageUrl",
          fit: BoxFit.cover,
          progressIndicatorBuilder: (context, url, downloadProgress) =>
              SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
          errorWidget: (context, url, error) => Icon(Icons.error),
        ),
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}

Widget keyboardImageWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/default_profile.png',
        fit: BoxFit.cover,
      );
    else
      return Stack(
        children: [
          CachedNetworkImage(
            imageUrl: "$imageUrl",
            fit: BoxFit.cover,
            progressIndicatorBuilder: (context, url, downloadProgress) =>
                SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
            errorWidget: (context, url, error) => Icon(Icons.error),
          ),
        ],
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}

Widget profileWidget({String? imageUrl,File? image}){
  if (image==null){
    if (imageUrl==null)
      return Image.asset(
        'assets/profile_default.png',
        fit: BoxFit.cover,
      );
    else
      return CachedNetworkImage(
        imageUrl: "$imageUrl",
        fit: BoxFit.cover,
        progressIndicatorBuilder: (context, url, downloadProgress) =>
            SizedBox(height: 50,width: 50,child: Container(margin: EdgeInsets.all(20),child: CircularProgressIndicator())),
        errorWidget: (context, url, error) => Image.asset("assets/profile_default.png"),
      );
  }else{
    return Image.file(image,fit: BoxFit.cover,);
  }
}