



import 'package:flutter/material.dart';

completeRideAlert(BuildContext context,{VoidCallback? onDeletePostClickListener}) {
  // set up the button
  Widget cancelButton = TextButton(
    child: Text("Cancel"),
    onPressed: () {
      Navigator.pop(context);
    },
  );
  Widget yesButton = TextButton(
    child: Text("Yes"),
    onPressed: onDeletePostClickListener,
  );

  // set up the AlertDialog
  AlertDialog alert = AlertDialog(
    title: Text("Complete Booked Ride?"),
    content: Text("Are you sure the ride is completed?"),
    actions: [
      cancelButton,
      yesButton
    ],
  );
  // show the dialog
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return alert;
    },
  );
}



