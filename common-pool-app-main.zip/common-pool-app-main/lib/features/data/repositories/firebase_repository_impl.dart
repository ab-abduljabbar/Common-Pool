


import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';

import '../../domain/entities/user_entity.dart';
import '../../domain/repositories/firebase_repository.dart';
import '../data_sources/remote/firebase_remote_data_source.dart';

class FirebaseRepositoryImpl implements FirebaseRepository {
  final FirebaseRemoteDataSource firebaseRemoteDataSource;

  FirebaseRepositoryImpl({required this.firebaseRemoteDataSource});

  // User

  @override
  Stream<List<UserEntity>> getAllDrivers() => firebaseRemoteDataSource.getAllDrivers();

  @override
  Future<void> loginUser(UserEntity user) async => firebaseRemoteDataSource.loginUser(user);

  Stream<List<UserEntity>> getAllUsers() => firebaseRemoteDataSource.getAllUsers();

  @override
  Future<void> signOut() async => firebaseRemoteDataSource.signOut();

  @override
  Future<void> registerUser(UserEntity user) async => firebaseRemoteDataSource.registerUser(user);

  @override
  Future<void> getCreateCurrentUser(UserEntity user) async => firebaseRemoteDataSource.getCreateCurrentUser(user);

  @override
  Future<String> getCurrentUid() async => firebaseRemoteDataSource.getCurrentUid();

  @override
  Future<bool> isSignIn() async => firebaseRemoteDataSource.isSignIn();

  @override
  Future<void> getUpdateUser(UserEntity user) async => firebaseRemoteDataSource.getUpdateUser(user);

  @override
  Future<bool> isCheckEmailVerification() async =>
      firebaseRemoteDataSource.isCheckEmailVerification();

  @override
  Stream<List<UserEntity>> getSingleUser(String uid) =>
      firebaseRemoteDataSource.getSingleUser(uid);

  // Book Ride

  @override
  Stream<List<BookRideEntity>> getAllBookRides() => firebaseRemoteDataSource.getAllBookRides();

  @override
  Future<void> getDeleteBookRide(BookRideEntity bookRideEntity) async => firebaseRemoteDataSource.getDeleteBookRide(bookRideEntity);


  @override
  Stream<List<BookRideEntity>> getMyBookRides() => firebaseRemoteDataSource.getMyBookRides();

  @override
  Future<void> getPostBookRide(BookRideEntity bookRideEntity) async => firebaseRemoteDataSource.getPostBookRide(bookRideEntity);

  @override
  Future<void> getUpdateBookRide(BookRideEntity bookRideEntity) async => firebaseRemoteDataSource.getUpdateBookRide(bookRideEntity);

  Stream<List<BookRideEntity>> getSingleBookRide(String bookRideId) => firebaseRemoteDataSource.getSingleBookRide(bookRideId);


  // Feedback

  @override
  Future<void> addFeedBack(FeedbackEntity service) async => firebaseRemoteDataSource.addFeedBack(service);

  @override
  Stream<List<FeedbackEntity>> getFeedBack(FeedbackEntity feedbackEntity) => firebaseRemoteDataSource.getFeedBack(feedbackEntity);

  @override
  Future<void> deleteFeedBack(FeedbackEntity service) async => firebaseRemoteDataSource.deleteFeedBack(service);

  @override
  Future<void> forgotPassword(String email) async => firebaseRemoteDataSource.forgotPassword(email);
}







