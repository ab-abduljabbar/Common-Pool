import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/consts.dart';
import 'package:common_pool_app/features/data/models/book_ride_model.dart';
import 'package:common_pool_app/features/data/models/feedback_model.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';

import '../../../domain/entities/user_entity.dart';
import '../../../presentation/widgets/common.dart';
import '../../models/user_model.dart';
import 'firebase_remote_data_source.dart';

class FirebaseRemoteDatSourceImpl implements FirebaseRemoteDataSource {
  final FirebaseFirestore firebaseFirestore;
  final FirebaseStorage firebaseStorage;
  final FirebaseAuth firebaseAuth;

  FirebaseRemoteDatSourceImpl({required this.firebaseFirestore, required this.firebaseStorage, required this.firebaseAuth});

  @override
  Future<void> signOut() async {
    await firebaseAuth.signOut();
  }

  @override
  Stream<List<UserEntity>> getAllUsers() {
    final userCollection = firebaseFirestore.collection(FirebaseConst.user);
    return userCollection.where("isVerified", isEqualTo: true).orderBy("createAt").snapshots().map((querySnapshot) => querySnapshot.docs.map((e) => UserModel.fromSnap(e)).toList());
  }

  @override
  Stream<List<UserEntity>> getAllDrivers() {
    final userCollection = firebaseFirestore.collection(FirebaseConst.user);
    return userCollection.where("accountType", isEqualTo: AccountConst.driver).snapshots().map(
          (querySnapshot) => querySnapshot.docs.map((e) => UserModel.fromSnap(e)).toList(),
        );
  }

  @override
  Stream<List<UserEntity>> getSingleUser(String uid) {
    final userCollection = firebaseFirestore.collection(FirebaseConst.user);
    return userCollection.where("uid", isEqualTo: uid).snapshots().map((querySnapshot) => querySnapshot.docs.map((e) => UserModel.fromSnap(e)).toList());
  }

  @override
  Future<void> forgotPassword(String email) async => firebaseAuth.sendPasswordResetEmail(email: email);

  @override
  Future<String> getCurrentUid() async => firebaseAuth.currentUser!.uid;

  @override
  Future<bool> isSignIn() async => firebaseAuth.currentUser?.uid != null;

  @override
  Future<bool> isCheckEmailVerification() async => firebaseAuth.currentUser!.emailVerified;

  @override
  Future<void> getUpdateUser(UserEntity user) async {
    Map<String, dynamic> userInformation = Map();

    final userCollection = firebaseFirestore.collection(FirebaseConst.user);

    if (user.photoUrl != null && user.photoUrl != "") userInformation['photoUrl'] = user.photoUrl;

    if (user.about != null && user.about != "") userInformation['about'] = user.about;


    if (user.locationPoint != null) userInformation['locationPoint'] = user.locationPoint;

    if (user.username != null && user.username != "") userInformation['username'] = user.username;

    if (user.phone != null && user.phone != "") userInformation['phone'] = user.phone;

    if (user.car != null && user.car != "") userInformation['car'] = user.car;

    if (user.carModel != null && user.carModel != "") userInformation['carModel'] = user.carModel;

    if (user.accountType != null && user.accountType != "") userInformation['accountType'] = user.accountType;

    if (user.numberOfSeats != null && user.numberOfSeats != "") userInformation['numberOfSeats'] = user.numberOfSeats;

    if (user.address != null && user.address != "") userInformation['address'] = user.address;

    if (user.isVerified == true) userInformation['isVerified'] = true;

    userCollection.doc(user.uid).update(userInformation);

    final userDocRef = await userCollection.doc(user.uid).get();
    // final memberShipMap = userDocRef.get("memberShip");

    return;
  }

  Future<void> getCreateCurrentUser(UserEntity user) async {
    final userCollection = firebaseFirestore.collection(FirebaseConst.user);
    final uid = await getCurrentUid();
    userCollection.doc(uid).get().then((userDoc) {
      final newUser = UserModel(
        username: user.username,
        uid: uid,
        about: "",
        address: user.address,
        car: user.car,
        carModel: user.carModel,
        createAt: Timestamp.now(),
        isVerified: false,
        locationPoint: user.locationPoint,
        numberOfSeats: user.numberOfSeats,
        phone: user.phone,
        photoUrl: "",
        totalRating: 0,
        email: user.email,
        accountType: user.accountType,
      ).toJson();
      if (!userDoc.exists) {
        userCollection.doc(uid).set(newUser);
        print("user registered");
        return;
      } else {
        userCollection.doc(uid).update(newUser);
        print("user already exist");
        return;
      }
    }).catchError((error) {
      print(error);
    });
  }

  @override
  Future<void> loginUser(UserEntity user) async {
    await firebaseAuth.signInWithEmailAndPassword(email: user.email!, password: user.password!).then((value) async {});
  }

  @override
  Future<void> registerUser(UserEntity user) async {
    try {
      await firebaseAuth.createUserWithEmailAndPassword(email: user.email!, password: user.password!).then((value) async {
        if (value.user?.uid != null) {
          await getCreateCurrentUser(user).then((value) {
            firebaseAuth.currentUser!.sendEmailVerification();
          });

          return;
        }
        return;
      });
    } on FirebaseAuthException catch (e) {
      if (e.code == 'email-already-in-use') {
        toast("The account already exists for that email.");
      }
    }
  }

  // Book Ride

  @override
  Stream<List<BookRideEntity>> getAllBookRides() {
    final bookRideCollection = firebaseFirestore.collection(FirebaseConst.bookRide);
    return bookRideCollection.orderBy("dateTime", descending: true).snapshots().map((querySnap) {
      return querySnap.docs.map((docSnap) => BookRideModel.fromSnap(docSnap)).toList();
    });
  }

  @override
  Stream<List<BookRideEntity>> getSingleBookRide(String bookRideId) {
    final bookRideCollection = firebaseFirestore.collection(FirebaseConst.bookRide);
    return bookRideCollection.where("bookRideId", isEqualTo: bookRideId).orderBy("dateTime", descending: true).snapshots().map((querySnap) {
      return querySnap.docs.map((docSnap) => BookRideModel.fromSnap(docSnap)).toList();
    });
  }

  @override
  Future<void> getDeleteBookRide(BookRideEntity bookRide) async {
    final bookRideCollection = firebaseFirestore.collection(FirebaseConst.bookRide);

    bookRideCollection.doc(bookRide.bookRideId).get().then((userDoc) {
      if (userDoc.exists) {
        print("bookRide deleted");
        bookRideCollection.doc(bookRide.bookRideId).delete();
      } else {
        print("not exist bookRide");
      }
    }).catchError((error) {
      print("error firebase $error");
    });
  }

  @override
  Stream<List<BookRideEntity>> getMyBookRides() {
    final userCollection = firebaseFirestore.collection(FirebaseConst.bookRide);
    return userCollection.orderBy("createAt", descending: true).snapshots().map((querySnap) {
      return querySnap.docs.map((docSnap) => BookRideModel.fromSnap(docSnap)).toList();
    });
  }

  @override
  Future<void> getPostBookRide(BookRideEntity bookRideEntity) async {
    final bookRideCollection = firebaseFirestore.collection(FirebaseConst.bookRide);

    final bookRiderId = bookRideCollection.doc().id;
    bookRideCollection.doc(bookRiderId).get().then((userDoc) {
      final newBookRide = BookRideModel(
              creatorId: bookRideEntity.creatorId,
              passengerPrice: bookRideEntity.passengerPrice,
              finalPrice: bookRideEntity.finalPrice,
              driverPrice: bookRideEntity.driverPrice,
              bookRideId: bookRiderId,
              driverId: bookRideEntity.driverId,
              priceAgreementStatus: BudgetAgreementStatus.notAgreeYet,
              driverLocation: bookRideEntity.driverLocation,
              destination: bookRideEntity.destination,
              dateTime: bookRideEntity.dateTime,
              currentLocation: bookRideEntity.currentLocation,
              address: bookRideEntity.address,
              bookingStatus: bookRideEntity.bookingStatus,)
          .toJson();

      if (!userDoc.exists) {
        print("new ride booked");
        bookRideCollection.doc(bookRiderId).set(newBookRide);
      } else {
        return;
      }
    }).catchError((error) {
      print("error firebase $error");
    });
  }

  @override
  Future<void> getUpdateBookRide(BookRideEntity bookRideEntity) async {
    Map<String, dynamic> userInformation = Map();

    final userCollection = firebaseFirestore.collection(FirebaseConst.bookRide);

    if (bookRideEntity.passengerPrice != null && bookRideEntity.passengerPrice != "") userInformation['passengerPrice'] = bookRideEntity.passengerPrice;

    if (bookRideEntity.priceAgreementStatus != null && bookRideEntity.priceAgreementStatus != "") userInformation['priceAgreementStatus'] = bookRideEntity.priceAgreementStatus;

    if (bookRideEntity.bookingStatus != null && bookRideEntity.bookingStatus != "") userInformation['bookingStatus'] = bookRideEntity.bookingStatus;

    if (bookRideEntity.driverPrice != null && bookRideEntity.driverPrice != "") userInformation['driverPrice'] = bookRideEntity.driverPrice;

    if (bookRideEntity.finalPrice != null && bookRideEntity.finalPrice != "") userInformation['finalPrice'] = bookRideEntity.finalPrice;

    if (bookRideEntity.driverLocation != null) userInformation['driverLocation'] = bookRideEntity.driverLocation;

    if (bookRideEntity.address != null && bookRideEntity.address != "") userInformation['address'] = bookRideEntity.address;

    userCollection.doc(bookRideEntity.bookRideId).update(userInformation);
  }

  // Feedback

  @override
  Future<void> addFeedBack(FeedbackEntity feedbackEntity) async {
    final feedbackCollection = firebaseFirestore.collection(FirebaseConst.user).doc(feedbackEntity.feedbackId).collection(FirebaseConst.feedback);

    final feedbackId = feedbackCollection.doc().id;

    final newFeedback = FeedbackModel(
      createAt: feedbackEntity.createAt,
      creatorId: feedbackEntity.creatorId,
      feedbackId: feedbackId,
      totalRating: feedbackEntity.totalRating,
      review: feedbackEntity.review,
      driverId: feedbackEntity.driverId,
    ).toDocument();

    final storySnapRef = await feedbackCollection.doc(feedbackId).get();

    if (!storySnapRef.exists) {
      feedbackCollection.doc(feedbackId).set(newFeedback).then((value) {
        ///updateCollection Review
        final userCollection = firebaseFirestore.collection(FirebaseConst.user).doc(feedbackEntity.feedbackId);

        userCollection.get().then((value) {
          if (value.exists) {
            final totalRatingValue = value.get("totalRating");

            final totalRating = num.parse(totalRatingValue.toString());

            userCollection.update({
              "totalRating": totalRating + 1,
            });
          }
          return;
        });
      });
    }
    return;
  }

  @override
  Future<void> deleteFeedBack(FeedbackEntity service) {
    // TODO: implement deleteFeedBack
    throw UnimplementedError();
  }

  @override
  Stream<List<FeedbackEntity>> getFeedBack(FeedbackEntity feedbackEntity) {
    final userCollection = firebaseFirestore.collection(FirebaseConst.user).doc(feedbackEntity.feedbackId).collection(FirebaseConst.feedback);
    return userCollection.snapshots().map((querySnapshot) {
      return querySnapshot.docs.map((e) => FeedbackModel.fromSnapshot(e)).toList();
    });
  }


}
