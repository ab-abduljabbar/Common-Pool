import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';

class StorageProviderRemoteDataSource {
  static FirebaseStorage _storage = FirebaseStorage.instance;


  static Future<String> uploadImages(
      {required File file, Function(bool isUploading)? onComplete}) async {
    onComplete!(true);

    final ref = _storage.ref().child(
        "images/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");
    print("file ${file.path}");

    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    onComplete(false);
    return await imageUrl;
  }


  static Future<String> uploadMultiPostSingleFile(
      {required File file}) async {


    final ref = _storage.ref().child(
        "posts/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");
    print("file ${file.path}");

    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();

    return await imageUrl;
  }
  static Future<String> uploadPost(
      {required File file, Function(bool isUploading)? onComplete}) async {
    onComplete!(true);

    final ref = _storage.ref().child(
        "posts/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");
    print("file ${file.path}");

    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    onComplete(false);
    return await imageUrl;
  }

  static Future<String> uploadComics(
      {required File file, Function(bool isUploading)? onComplete}) async {
    onComplete!(true);

    final ref = _storage.ref().child(
        "comics/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");


    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    onComplete(false);
    return await imageUrl;
  }



  static Future<List<String>> uploadMultiImagePost(
      {required List<File> images, required Function(bool isUploading) onComplete}) async {
    onComplete(true);
    var downloadedImagesUrl=await Future.wait(images.map((file) => uploadMultiPostSingleFile(file: file)));

    onComplete(false);
    return downloadedImagesUrl;
  }



  static Future<String> uploadFile(
      {required File file, Function(bool isUploading)? onComplete}) async {
    onComplete!(true);

    final ref = _storage.ref().child(
        "Documents/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");
    print("file ${file.path}");

    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    onComplete(false);
    return await imageUrl;
  }

  static Future<String> uploadAudioMessage(
      {required File file, Function(bool isUploading)? onComplete}) async {
    onComplete!(true);
    final ref = _storage.ref().child(
        "audio/${DateTime.now().millisecondsSinceEpoch}${getNameOnly(file.path)}");
    print("file ${file.path}");

    final uploadTask = ref.putFile(file);

    final imageUrl =
    (await uploadTask.whenComplete(() {})).ref.getDownloadURL();
    onComplete(false);
    return await imageUrl;
  }

  static String getNameOnly(String path) {
    return path.split('/').last.split('%').last.split("?").first;
  }
}
