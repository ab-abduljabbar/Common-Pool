
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';

class FeedbackModel extends FeedbackEntity {
  final String? creatorId;
  final String? feedbackId;
  final Timestamp? createAt;
  final num? totalRating;
  final String? review;
  final String? driverId;

  FeedbackModel({
    this.creatorId,
    this.feedbackId,
    this.createAt,
    this.totalRating,
    this.review,
    this.driverId,
  }) : super(
    creatorId: creatorId,
      feedbackId: feedbackId,
    createAt: createAt,
    totalRating: totalRating,
    review: review,
    driverId: driverId
  );


  factory FeedbackModel.fromSnapshot(DocumentSnapshot snapshot) {
    return FeedbackModel(
      creatorId: snapshot.get('creatorId'),
      feedbackId: snapshot.get('feedbackId'),
      createAt: snapshot.get('createAt'),
      review: snapshot.get('review'),
      totalRating: snapshot.get('totalRating'),
      driverId: snapshot.get('driverId'),
    );
  }



  Map<String, dynamic> toDocument() {
    return {
      "creatorId": creatorId,
      "feedbackId": feedbackId,
      "createAt": createAt,
      "totalRating": totalRating,
      "driverId": driverId,
      "review": review,
    };
  }
}