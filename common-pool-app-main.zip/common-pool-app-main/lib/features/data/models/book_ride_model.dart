import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
/// FIXME book ride entity
/// Fixed
class BookRideModel extends BookRideEntity {
  final String? bookRideId;
  final Timestamp? dateTime;
  final String? address;
  final String? creatorId;
  final String? priceAgreementStatus;
  final String? driverId;
  final GeoPoint? currentLocation;
  final GeoPoint? destination;
  final String? bookingStatus;
  final String? passengerPrice;
  final String? driverPrice;
  final String? finalPrice;
  final GeoPoint? driverLocation;

  BookRideModel({
    this.bookRideId,
    this.passengerPrice,
    this.driverPrice,
    this.finalPrice,
    this.priceAgreementStatus,
    this.dateTime,
    this.address,
    this.creatorId,
    this.driverId,
    this.currentLocation,
    this.destination,
    this.bookingStatus,
    this.driverLocation,
  }) : super(
    address: address,
    creatorId: creatorId,
      driverId: driverId,
    currentLocation: currentLocation,
      priceAgreementStatus: priceAgreementStatus,
    dateTime: dateTime,
    destination: destination,
    bookingStatus: bookingStatus,
    bookRideId: bookRideId,
    driverPrice: driverPrice,
    finalPrice: finalPrice,
    passengerPrice: passengerPrice,
      driverLocation: driverLocation,
  );

  static BookRideModel fromSnap(DocumentSnapshot snap) {
    var snapshot = snap.data() as Map<String, dynamic>;

    return BookRideModel(
      creatorId: snapshot["creatorId"],
      priceAgreementStatus: snapshot["priceAgreementStatus"],
      driverId: snapshot["driverId"],
      currentLocation: snapshot["currentLocation"],
      dateTime: snapshot["dateTime"],
      bookingStatus: snapshot["bookingStatus"],
      passengerPrice: snapshot["passengerPrice"],
      driverPrice: snapshot["driverPrice"],
      finalPrice: snapshot["finalPrice"],
      address: snapshot["address"],
      bookRideId: snapshot["bookRideId"],
      destination: snapshot["destination"],
      driverLocation: snapshot["driverLocation"],
    );
  }

  Map<String, dynamic> toJson() => {
    "address": address,
    "priceAgreementStatus": priceAgreementStatus,
    "creatorId": creatorId,
    "driverId": driverId,
    "currentLocation": currentLocation,
    "driverLocation": driverLocation,
    "dateTime": dateTime,
    "destination": destination,
    "bookingStatus": bookingStatus,
    "bookRideId": bookRideId,
    "driverPrice": driverPrice,
    "finalPrice": finalPrice,
    "passengerPrice": passengerPrice,
  };
}
