import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';

class UserModel extends UserEntity {
  final String? uid;
  final Timestamp? createAt;
  final String? about;
  final String? photoUrl;
  final String? username;
  final String? email;
  final String? phone;
  final String? car;
  final String? carModel;
  final String? numberOfSeats;
  final num? totalRating;
  final bool? isVerified;
  final GeoPoint? locationPoint;
  final String? address;
  final String? accountType;

  UserModel({
    this.uid,
    this.createAt,
    this.about,
    this.photoUrl,
    this.username,
    this.email,
    this.phone,
    this.car,
    this.carModel,
    this.numberOfSeats,
    this.totalRating,
    this.isVerified,
    this.locationPoint,
    this.address,
    this.accountType,
  }) : super(
    uid: uid,
    about: about,
    address: address,
    car: car,
    carModel: carModel,
    createAt: createAt,
    email: email,
    isVerified: isVerified,
    locationPoint: locationPoint,
    numberOfSeats: numberOfSeats,
    phone: phone,
    photoUrl: photoUrl,
    totalRating: totalRating,
    username: username,
      accountType: accountType
  );

  static UserModel fromSnap(DocumentSnapshot snap) {
    var snapshot = snap.data() as Map<String, dynamic>;

    return UserModel(
      username: snapshot["username"],
      isVerified: snapshot["isVerified"],
      uid: snapshot["uid"],
      email: snapshot["email"],
      photoUrl: snapshot["photoUrl"],
      createAt: snapshot["createAt"],
      address: snapshot["address"],
      phone: snapshot["phone"],
      about: snapshot["about"],
      car: snapshot["car"],
      carModel: snapshot["carModel"],
      numberOfSeats: snapshot["numberOfSeats"],
      locationPoint: snapshot["locationPoint"],
      totalRating: snapshot["totalRating"],
      accountType: snapshot["accountType"],
    );
  }

  Map<String, dynamic> toJson() => {
    "username": username,
    "uid": uid,
    "email": email,
    "photoUrl": photoUrl,
    "isVerified": isVerified,
    "car": car,
    "carModel": carModel,
    "numberOfSeats": numberOfSeats,
    "locationPoint": locationPoint,
    "totalRating": totalRating,
    "phone": phone,
    "address": address,
    "about": about,
    "accountType": accountType,
  };
}
