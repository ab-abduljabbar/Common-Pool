import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class BookRideEntity extends Equatable {
  final String? bookRideId;
  final Timestamp? dateTime;
  final String? address;
  final String? creatorId;
  final String? driverId;
  final GeoPoint? currentLocation;
  final GeoPoint? destination;
  final GeoPoint? driverLocation;
  final String? bookingStatus;
  final String? priceAgreementStatus;
  final String? passengerPrice;
  final String? driverPrice;
  final String? finalPrice;

  BookRideEntity({
    this.bookRideId,
    this.passengerPrice,
    this.finalPrice,
    this.driverPrice,
    this.driverLocation,
    this.dateTime,
    this.address,
    this.creatorId,
    this.driverId,
    this.currentLocation,
    this.destination,
    this.priceAgreementStatus,
    this.bookingStatus,
  });

  @override
  List<Object?> get props => [
    bookRideId,
    dateTime,
    address,
    creatorId,
    driverId,
    currentLocation,
    driverLocation,
    destination,
    bookingStatus,
    driverPrice,
    passengerPrice,
    priceAgreementStatus,
    finalPrice,
  ];
}
