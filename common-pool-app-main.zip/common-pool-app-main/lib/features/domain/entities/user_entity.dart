import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class UserEntity extends Equatable {
  final String? uid;
  final Timestamp? createAt;
  final String? about;
  final String? photoUrl;
  final String? username;
  final String? email;
  final String? password;
  final String? phone;
  final String? car;
  final String? carModel;
  final String? numberOfSeats;
  final num? totalRating;
  final bool? isVerified;
  final GeoPoint? locationPoint;
  final String? address;
  final String? accountType;

  UserEntity({
    this.uid,
    this.createAt,
    this.about,
    this.photoUrl,
    this.username,
    this.email,
    this.password,
    this.phone,
    this.car,
    this.carModel,
    this.numberOfSeats,
    this.totalRating,
    this.isVerified,
    this.locationPoint,
    this.address,
    this.accountType,
  });

  @override
  List<Object?> get props => [
        uid,
        createAt,
        about,
        photoUrl,
        username,
        email,
        password,
        phone,
        car,
        carModel,
        numberOfSeats,
        totalRating,
        isVerified,
        locationPoint,
        address,
    accountType,
      ];
}
