import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class FeedbackEntity extends Equatable {
  final String? creatorId;
  final String? feedbackId;
  final Timestamp? createAt;
  final num? totalRating;
  final String? review;
  final String? driverId;

  FeedbackEntity({
    this.creatorId,
    this.feedbackId,
    this.createAt,
    this.totalRating,
    this.review,
    this.driverId,
  });

  @override
  List<Object?> get props => [
    creatorId,
    feedbackId,
    createAt,
    totalRating,
    review,
    driverId,
  ];


}
