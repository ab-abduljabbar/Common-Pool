

import '../../entities/user_entity.dart';
import '../../repositories/firebase_repository.dart';

class LoginUserUseCase{
  final FirebaseRepository repository;

  LoginUserUseCase({required this.repository});

  Future<void> call(UserEntity user)async{
    return repository.loginUser(user);
  }
}