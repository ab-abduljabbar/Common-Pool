


import '../../repositories/firebase_repository.dart';

class IsCheckEmailVerificationUseCase{
  final FirebaseRepository repository;

  IsCheckEmailVerificationUseCase({required this.repository});

  Future<bool> call()async{
    return repository.isCheckEmailVerification();
  }
}