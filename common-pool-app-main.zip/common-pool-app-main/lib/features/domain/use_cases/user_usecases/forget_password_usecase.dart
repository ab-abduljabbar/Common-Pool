


import '../../repositories/firebase_repository.dart';

class ForgetPasswordUseCase{
  final FirebaseRepository repository;

  ForgetPasswordUseCase({required this.repository});

  Future<void> call(String email)async{
    return repository.forgotPassword(email);
  }
}