




import '../../entities/user_entity.dart';
import '../../repositories/firebase_repository.dart';

class GetAllDriversUseCase{
  final FirebaseRepository repository;

  GetAllDriversUseCase({required this.repository});

  Stream<List<UserEntity>> call() {
    return repository.getAllDrivers();
  }
}