





import '../../entities/feedback_entity.dart';
import '../../repositories/firebase_repository.dart';

class GetAllFeedbackUseCase{
  final FirebaseRepository repository;

  GetAllFeedbackUseCase({required this.repository});

  Stream<List<FeedbackEntity>> call(FeedbackEntity feedbackEntity){
    return repository.getFeedBack(feedbackEntity);
  }
}