



import 'package:flutter/material.dart';

import '../../entities/feedback_entity.dart';
import '../../repositories/firebase_repository.dart';

class AddFeedbackUseCase{
  final FirebaseRepository repository;

  AddFeedbackUseCase({required this.repository});

  Future<void> call(FeedbackEntity feedback){
    return repository.addFeedBack(feedback);
  }
}