




import '../../entities/feedback_entity.dart';
import '../../repositories/firebase_repository.dart';

class DeleteFeedbackUseCase{
  final FirebaseRepository repository;

  DeleteFeedbackUseCase({required this.repository});

  Future<void> call(FeedbackEntity feedback){
    return repository.deleteFeedBack(feedback);
  }
}