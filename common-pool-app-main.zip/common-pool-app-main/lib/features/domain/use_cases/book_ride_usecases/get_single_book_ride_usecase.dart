




import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import '../../repositories/firebase_repository.dart';

class GetSingleBookRideUseCase{
  final FirebaseRepository repository;

  GetSingleBookRideUseCase({required this.repository});

  Stream<List<BookRideEntity>> call(String bookRideId){
    return repository.getSingleBookRide(bookRideId);
  }
}