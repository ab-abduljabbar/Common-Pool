



import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import '../../repositories/firebase_repository.dart';

class GetMyBookRidesUseCase{
  final FirebaseRepository repository;

  GetMyBookRidesUseCase({required this.repository});

  Stream<List<BookRideEntity>> call(){
    return repository.getMyBookRides();
  }
}