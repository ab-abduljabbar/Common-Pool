





import '../../entities/book_ride_entity.dart';
import '../../repositories/firebase_repository.dart';

class GetDeleteBookRidesUseCase{
  final FirebaseRepository repository;

  GetDeleteBookRidesUseCase({required this.repository});

  Future<void> call(BookRideEntity bookRideEntity){
    return repository.getDeleteBookRide(bookRideEntity);
  }
}