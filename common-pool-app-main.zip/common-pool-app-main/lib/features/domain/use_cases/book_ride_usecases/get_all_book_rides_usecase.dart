




import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import '../../repositories/firebase_repository.dart';

class GetAllBookRidesUseCase{
  final FirebaseRepository repository;

  GetAllBookRidesUseCase({required this.repository});

  Stream<List<BookRideEntity>> call(){
    return repository.getAllBookRides();
  }
}