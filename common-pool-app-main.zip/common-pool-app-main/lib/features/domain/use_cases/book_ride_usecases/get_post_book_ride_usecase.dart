







import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import '../../repositories/firebase_repository.dart';

class GetPostBookRidesUseCase{
  final FirebaseRepository repository;

  GetPostBookRidesUseCase({required this.repository});

  Future<void> call(BookRideEntity bookRideEntity){
    return repository.getPostBookRide(bookRideEntity);
  }
}