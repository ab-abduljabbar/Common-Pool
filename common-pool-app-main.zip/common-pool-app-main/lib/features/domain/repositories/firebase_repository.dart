

import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';

import '../entities/feedback_entity.dart';
import '../entities/user_entity.dart';

abstract class FirebaseRepository {
  // Auth
  Future<void> registerUser(UserEntity user);
  Future<void> loginUser(UserEntity user);
  Future<void> signOut();
  Future<String> getCurrentUid();
  Future<bool> isSignIn();
  Future<void> getUpdateUser(UserEntity user);
  Future<bool> isCheckEmailVerification();
  Future<void> getCreateCurrentUser(UserEntity user);
  Stream<List<UserEntity>> getAllUsers();
  Stream<List<UserEntity>> getSingleUser(String uid);
  Stream<List<UserEntity>> getAllDrivers();
  Future<void> forgotPassword(String email);


  // Book Ride
  Stream<List<BookRideEntity>> getAllBookRides();
  Stream<List<BookRideEntity>> getMyBookRides();
  Stream<List<BookRideEntity>> getSingleBookRide(String bookRideId);
  Future<void> getPostBookRide(BookRideEntity bookRideEntity);
  Future<void> getDeleteBookRide(BookRideEntity bookRideEntity);
  Future<void> getUpdateBookRide(BookRideEntity bookRideEntity);

  // Feedback
  Future<void> addFeedBack(FeedbackEntity service);
  Future<void> deleteFeedBack(FeedbackEntity service);
  Stream<List<FeedbackEntity>> getFeedBack(FeedbackEntity feedbackEntity);

}