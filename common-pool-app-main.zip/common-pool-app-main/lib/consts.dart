import 'package:common_pool_app/features/domain/entities/book_ride_entity.dart';
import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:flutter/material.dart';

class PageConst {
  // Authentication
  static const String signUpPage = "signUpPage";
  static const String loginPage = "loginPage";
  static const String forgetPasswordPage = "forgetPasswordPage";

  // Initial
  static const String homePage = "homePage";


  // Verification
  static const String otpVerificationPage = "otpVerificationPage";


  // Profile
  static const String profilePage = "profilePage";
  static const String viewProfilePage = "viewProfilePage";
  static const String editProfilePage = "editProfilePage";


  // Feedback
  static const String feedBackPage = "feedBackPage";

  // Rides
  static const String bookRidePage = "bookRidePage";

}

class FirebaseConst {
  static const String user = "user";
  static const String feedback = "feedback";
  static const String bookRide = "bookRide";
}

class BookingStatusConst {
  static const String waiting = "waiting";
  static const String complete = "complete";
  static const String completeFeedback = "completeFeedback";
  static const String inProgress = "inProgress";
}

class AccountConst {
  static const String driver = "driver";
  static const String passenger = "passenger";
}
class BudgetAgreementStatus {
  static const String notAgreeYet = "notAgreeYet";
  static const String agreed = "agreed";
}

class ErrorPage extends StatelessWidget {
  const ErrorPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Error"),
      ),
      body: Center(
        child: Text("Error"),
      ),
    );
  }
}

dynamic routeBuilder(Widget child) {
  return MaterialPageRoute(builder: (context) => child);
}

/// [Deprecated]

// class MultipleArgs {
//   final UserEntity userEntity;
//   final FeedbackEntity feedbackEntity;
//
//   MultipleArgs({required this.userEntity, required this.feedbackEntity});
// }


