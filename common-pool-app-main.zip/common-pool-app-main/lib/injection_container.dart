import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:common_pool_app/features/domain/repositories/firebase_repository.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_all_book_rides_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_delete_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_my_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_post_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_single_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_single_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/book_ride_usecases/get_update_book_ride_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/feedback/add_feedback_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/feedback/delete_feedback_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/feedback/get_all_feedback_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_all_drivers_usecase.dart';
import 'package:common_pool_app/features/domain/use_cases/user_usecases/get_all_drivers_usecase.dart';
import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/driver/driver_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/driver/driver_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/feedback/feedback_cubit.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get_it/get_it.dart';
import 'features/data/data_sources/remote/firebase_remote_data_source.dart';
import 'features/data/data_sources/remote/firebase_remote_data_source_impl.dart';
import 'features/data/repositories/firebase_repository_impl.dart';
import 'features/domain/use_cases/user_usecases/forget_password_usecase.dart';
import 'features/domain/use_cases/user_usecases/get_all_users_usecase.dart';
import 'features/domain/use_cases/user_usecases/get_create_current_user_usecase.dart';
import 'features/domain/use_cases/user_usecases/get_current_uid_usecase.dart';
import 'features/domain/use_cases/user_usecases/get_single_user_usecase.dart';
import 'features/domain/use_cases/user_usecases/get_update_user.dart';
import 'features/domain/use_cases/user_usecases/is_check_email_verification_usecase.dart';
import 'features/domain/use_cases/user_usecases/is_sign_in_usecase.dart';
import 'features/domain/use_cases/user_usecases/login_user_usecase.dart';
import 'features/domain/use_cases/user_usecases/register_user_usecase.dart';
import 'features/domain/use_cases/user_usecases/sign_out_usecase.dart';
import 'features/presentation/cubit/auth/auth_cubit.dart';
import 'features/presentation/cubit/auth/credential/credential_cubit.dart';
import 'features/presentation/cubit/single_book_ride/single_book_ride_cubit.dart';
import 'features/presentation/cubit/single_user/single_user_cubit.dart';
import 'features/presentation/cubit/user/user_cubit.dart';

final sl = GetIt.instance;

Future<void> init() async {
  // injecting Cubits

  /// [Authentication]
  sl.registerFactory<AuthCubit>(
        () => AuthCubit(
      signOutUseCase: sl.call(),
      isSignInUseCase: sl.call(),
      getCurrentUidUseCase: sl.call(),
    ),
  );

  sl.registerFactory<CredentialCubit>(
        () => CredentialCubit(
          forgetPasswordUseCase: sl.call(),
      loginUserUseCase: sl.call(),
      registerUserUseCase: sl.call(),
      getCreateCurrentUserUseCase: sl.call(),
      isCheckEmailVerificationUseCase: sl.call(),
    ),
  );

  sl.registerFactory<FeedbackCubit>(
        () => FeedbackCubit(
          addFeedbackUseCase: sl.call(),
          deleteFeedbackUseCase: sl.call(),
          getAllFeedbackUseCase: sl.call(),
    ),
  );

  sl.registerFactory<BookRideCubit>(
        () => BookRideCubit(
          getAllBookRidesUseCase: sl.call(),
          getDeleteBookRidesUseCase: sl.call(),
          getPostBookRidesUseCase: sl.call(),
          getUpdateBookRidesUseCase: sl.call(),
    ),
  );

  sl.registerFactory<UserCubit>(
        () => UserCubit(getAllUsersUseCase: sl.call(), getUpdateUserUseCase: sl.call()),
  );


  sl.registerFactory<DriverCubit>(
        () => DriverCubit(getAllDriversUseCase: sl.call()),
  );

  sl.registerFactory<SingleBookRideCubit>(
        () => SingleBookRideCubit(getSingleBookRideUseCase: sl.call()),
  );



  sl.registerFactory<SingleUserCubit>(
        () => SingleUserCubit(getSingleUserUseCase: sl.call()),
  );



  // Injecting UseCases

  /// [User]
  sl.registerLazySingleton<GetSingleUserUseCase>(() => GetSingleUserUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<ForgetPasswordUseCase>(() => ForgetPasswordUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetAllDriversUseCase>(() => GetAllDriversUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetAllUsersUseCase>(() => GetAllUsersUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<IsSignInUseCase>(() => IsSignInUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetCreateCurrentUserUseCase>(() => GetCreateCurrentUserUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetCurrentUidUseCase>(() => GetCurrentUidUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<LoginUserUseCase>(() => LoginUserUseCase(
    repository: sl.call(),
  ));
  sl.registerLazySingleton<IsCheckEmailVerificationUseCase>(() => IsCheckEmailVerificationUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<RegisterUserUseCase>(() => RegisterUserUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<SignOutUseCase>(() => SignOutUseCase(
    repository: sl.call(),
  ));


  sl.registerLazySingleton<GetUpdateUserUseCase>(() => GetUpdateUserUseCase(
    repository: sl.call(),
  ));

  // Book Ride

  sl.registerLazySingleton<GetAllBookRidesUseCase>(() => GetAllBookRidesUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetSingleBookRideUseCase>(() => GetSingleBookRideUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetDeleteBookRidesUseCase>(() => GetDeleteBookRidesUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetMyBookRidesUseCase>(() => GetMyBookRidesUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetPostBookRidesUseCase>(() => GetPostBookRidesUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<GetUpdateBookRidesUseCase>(() => GetUpdateBookRidesUseCase(
    repository: sl.call(),
  ));

  // Feedback

  sl.registerLazySingleton<GetAllFeedbackUseCase>(() => GetAllFeedbackUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<DeleteFeedbackUseCase>(() => DeleteFeedbackUseCase(
    repository: sl.call(),
  ));

  sl.registerLazySingleton<AddFeedbackUseCase>(() => AddFeedbackUseCase(
    repository: sl.call(),
  ));


  // Injecting Repository

  /// [Repository]
  sl.registerLazySingleton<FirebaseRepository>(() => FirebaseRepositoryImpl(firebaseRemoteDataSource: sl.call()));

  /// [Remote Data Source]
  sl.registerLazySingleton<FirebaseRemoteDataSource>(() => FirebaseRemoteDatSourceImpl(
    firebaseAuth: sl.call(),
    firebaseFirestore: sl.call(),
    firebaseStorage: sl.call(),
  ));

  // External

  final FirebaseFirestore firebaseFirestore = FirebaseFirestore.instance;
  sl.registerLazySingleton<FirebaseFirestore>(() => firebaseFirestore);

  final FirebaseAuth firebaseAuth = FirebaseAuth.instance;
  sl.registerLazySingleton<FirebaseAuth>(() => firebaseAuth);

  final FirebaseStorage firebaseStorage = FirebaseStorage.instance;
  sl.registerLazySingleton<FirebaseStorage>(() => firebaseStorage);
}
