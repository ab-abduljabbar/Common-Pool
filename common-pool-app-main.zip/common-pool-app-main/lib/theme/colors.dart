
import 'package:flutter/material.dart';

const primaryColor = Color.fromRGBO(63, 214, 98, 1.0);
const whiteColor = Color.fromRGBO(255, 255, 255, 1.0);