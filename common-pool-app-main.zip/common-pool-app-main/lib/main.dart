import 'package:common_pool_app/features/presentation/cubit/book_ride/book_ride_cubit.dart';
import 'package:common_pool_app/features/presentation/cubit/feedback/feedback_cubit.dart';
import 'package:common_pool_app/features/presentation/pages/auth/login_page.dart';
import 'package:common_pool_app/features/presentation/pages/splash/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'features/presentation/cubit/auth/auth_cubit.dart';
import 'features/presentation/cubit/auth/credential/credential_cubit.dart';
import 'features/presentation/cubit/driver/driver_cubit.dart';
import 'features/presentation/cubit/single_book_ride/single_book_ride_cubit.dart';
import 'features/presentation/cubit/single_user/single_user_cubit.dart';
import 'features/presentation/cubit/user/user_cubit.dart';
import 'features/presentation/pages/email_verification/check_email_verification.dart';
import 'injection_container.dart' as di;
import 'on_generate_route.dart';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await di.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<AuthCubit>(
          create: (_) => di.sl<AuthCubit>()..appStarted(context),
        ),
        BlocProvider<CredentialCubit>(
          create: (_) => di.sl<CredentialCubit>(),
        ),
        BlocProvider<UserCubit>(
          create: (_) => di.sl<UserCubit>(),
        ),
        BlocProvider<SingleUserCubit>(
          create: (_) => di.sl<SingleUserCubit>(),
        ),
        BlocProvider<FeedbackCubit>(
          create: (_) => di.sl<FeedbackCubit>(),
        ),
        BlocProvider<BookRideCubit>(
          create: (_) => di.sl<BookRideCubit>(),
        ),
        BlocProvider<DriverCubit>(
          create: (_) => di.sl<DriverCubit>()..getDrivers(),
        ),
        BlocProvider<SingleBookRideCubit>(
          create: (_) => di.sl<SingleBookRideCubit>(),
        ),
      ],
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Common Pool',
        // home: SplashScreen(),
        initialRoute: '/',
        onGenerateRoute: OnGenerateRoute.route,
        routes: {
          "/": (context) {
            return SplashScreen(
              child: BlocBuilder<AuthCubit, AuthState>(builder: (context, currentState) {
                if (currentState is Authenticated) {
                  return CheckEmailVerification(
                    uid: currentState.uid,
                  );
                } else {
                  return LoginPage();
                }
              })
            );
          }
        },
      ),
    );
  }
}

