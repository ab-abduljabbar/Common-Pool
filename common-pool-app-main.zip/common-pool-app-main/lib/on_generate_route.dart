import 'package:common_pool_app/features/domain/entities/feedback_entity.dart';
import 'package:common_pool_app/features/domain/entities/user_entity.dart';
import 'package:common_pool_app/features/presentation/pages/auth/login_page.dart';
import 'package:common_pool_app/features/presentation/pages/auth/register_page.dart';
import 'package:common_pool_app/features/presentation/pages/profile/sub_pages/profile_view_page.dart';
import 'package:flutter/material.dart';

import 'consts.dart';
import 'features/presentation/pages/auth/forgot_password_page.dart';
import 'features/presentation/pages/feedback/feedback_page.dart';
import 'features/presentation/pages/profile/sub_pages/edit_profile_page.dart';

class OnGenerateRoute {
  static Route<dynamic> route(RouteSettings settings) {
    final args = settings.arguments;

    switch (settings.name) {
      case "/": {
        return materialBuilder(
          widget: ErrorPage(),
        );
      }
      case PageConst.forgetPasswordPage:
        {
          return materialBuilder(
            widget: ForgetPasswordPage(),
          );
        }
      case PageConst.loginPage:
        {
          return materialBuilder(
            widget: LoginPage(),
          );
        }


      case PageConst.signUpPage:
        {
          return materialBuilder(
            widget: RegisterPage(),
          );
        }
      case PageConst.editProfilePage:
        {
          if (args is UserEntity) {
            return materialBuilder(
              widget: EditProfilePage(userEntity: args,),
            );

          } else {
            return materialBuilder(
              widget: ErrorPage(),
            );
          }

        }

      case PageConst.feedBackPage:
        {
          if (args is UserEntity) {
            return materialBuilder(
              widget: FeedbackPage(driver: args),
            );

          } else {
            return materialBuilder(
              widget: ErrorPage(),
            );
          }

        }

      case PageConst.viewProfilePage:
        {
          if (args is UserEntity) {
            return materialBuilder(
              widget: ViewProfilePage(userEntity: args,),
            );

          } else {
            return materialBuilder(
              widget: ErrorPage(),
            );
          }

        }

      default:
        return materialBuilder(
          widget: ErrorPage(),
        );
    }
  }
}

class ErrorPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("error"),
      ),
      body: Center(
        child: Text("error"),
      ),
    );
  }
}

MaterialPageRoute materialBuilder({required Widget widget}) {
  return MaterialPageRoute(builder: (_) => widget);
}
